# Commands Reference

## enmarchia init

Inicializa ENMARCHIA en el proyecto actual.

Versiones requeridas por ENMARCHIA:

- specify-cli v0.5.0
- @bradygaster/squad-cli v0.9.1

Compatibilidad de ENMARCHIA:

- v0.1.4 o superior: incluye hardening de `launch` en Windows/Node.js 24 (evita `spawn EINVAL`), evita duplicado de `--execute` y autocrea labels `squad:<member>` faltantes antes del triage.
- v0.1.3: inicializa Spec-Kit automáticamente en Windows, soporta carpetas nnn-xxx, bridge requiere --spec-path, `--force` reprocesa tareas anotadas, parsea `tasks.md` con CRLF y corrige sync de conocimiento en ESM/Node.js 24.
- v0.1.2: bridge requiere --spec-path.
- v0.1.1: incluye --with-squad-copilot, bridge sin --spec-path.
- v0.1.0: no incluye --with-squad-copilot.

Uso:

enmarchia init [options]

Opciones:

- --owner <owner>: owner de GitHub (usuario u organizacion).
- --repo <repo>: nombre del repositorio.
- --force: re-inicializa si ya existe configuracion.
- --with-spec-kit: ejecuta specify init desde ENMARCHIA.
- --with-squad: ejecuta squad init desde ENMARCHIA.
- --with-squad-copilot: ejecuta squad copilot despues de squad init (requiere v0.1.1+).
- -y, --yes: evita prompts interactivos.

Resultados:

- Crea .enmarchia.json.
- Crea squad.agent.md.
- Crea .copilot/enmarchia.md.
- Crea specs/CONSTITUTION.md si no existe.
- Puede inicializar Spec-Kit y Squad con flags.

Ejemplo:

enmarchia init --owner acme --repo api-core --with-spec-kit --with-squad --with-squad-copilot --yes

Fallback para v0.1.0:
enmarchia init --owner acme --repo api-core --with-spec-kit --with-squad --yes
squad copilot

## enmarchia bridge

Convierte tareas de Spec-Kit en issues de GitHub.

**Prerequisito importante:** la rama actual debe estar mergeada en `main`. La configuración de Squad (.squad/team.md y .squad/agents/*) reside en la rama por defecto (main) del repositorio, y GitHub Actions la lee desde allí. Si ejecutas `bridge` desde una rama de feature, asegúrate de que la configuración del equipo esté disponible en main.

Uso:

enmarchia bridge --spec-path <path> [options]

Opciones:

- --spec-path <path>: (obligatorio) ruta a la carpeta de especificación (ej: specs/001-tetris-console-game o spec-user-auth).
- --dry-run: muestra preview sin crear issues.
- --force: ignora anotaciones y reprocesa.
- --skip-sync: evita auto-sync tras bridge.

Formato de ruta soportado en --spec-path:

- ID directo: 001-tetris-console-game o spec-user-auth
- Ruta relativa: specs/001-tetris-console-game o ./specs/spec-user-auth
- Ruta absoluta: C:/repo/specs/001-tetris-console-game
- Separadores Windows y Unix: \\ o /

Resultados:

- Lee tasks.md de la carpeta indicada.
- Crea un issue por tarea pendiente sin issue number.
- Con --force, crea issue tambien para tareas no completadas aunque ya tengan `(#N)`.
- Anota tasks.md con (#N).
- Puede sincronizar conocimiento de agentes automaticamente.

Ejemplos:

- enmarchia bridge --spec-path specs/001-tetris-console-game
- enmarchia bridge --spec-path spec-user-auth --dry-run
- enmarchia bridge --spec-path 002-api-core --skip-sync
- enmarchia bridge --spec-path .\\specs\\001-tetris-console-game

## enmarchia sync

Sincroniza conocimiento de spec/plan a Squad.

Uso:

enmarchia sync [options]

Opciones:

- --feature <id>: sincroniza solo una feature.
- --agents <names...>: sincroniza solo agentes indicados.

Resultados:

- Escribe .squad/enmarchia-specs.md.
- Actualiza .squad/agents/<agent>/history.md.

Ejemplos:

- enmarchia sync
- enmarchia sync --feature spec-user-auth
- enmarchia sync --agents backend tester

## enmarchia launch

Lanza ejecucion autonoma de Squad para issues de ENMARCHIA.

Uso:

enmarchia launch [options]

Opciones:

- --interval <minutes>: intervalo de polling.
- --agent-cmd <cmd>: comando del agente.
- --copilot-flags <flags>: flags para runner del agente.
- --auth-user <user>: usuario de autenticacion GitHub.
- --log-file <path>: archivo de log espejo.
- --state-backend <backend>: in-memory | git-notes | orphan-branch.
- --overnight-start <HH:MM>: pausa nocturna.
- --overnight-end <HH:MM>: reanudacion nocturna.
- --dry-run: imprime comando sin lanzar.
- --health: consulta estado del watch.

Resultados:

- Ejecuta `squad triage` en modo de ejecucion continua con parametros compatibles.
- Si `.squad/team.md` no tiene miembros, genera roster automaticamente segun tareas pendientes y luego lanza Squad.

Ejemplos:

- enmarchia launch
- enmarchia launch --interval 5
- enmarchia launch --overnight-start 20:00 --overnight-end 08:00
- enmarchia launch --health

## enmarchia status

Muestra salud del pipeline completo.

Uso:

enmarchia status [options]

Opciones:

- --json: salida en JSON.

Muestra:

- Estado de Spec-Kit (features/tareas).
- Estado de Squad (agentes/watch).
- Estado del bridge (issues y tareas sin bridge).
