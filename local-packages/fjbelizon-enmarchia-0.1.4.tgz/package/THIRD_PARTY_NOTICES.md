# Third-Party Notices

This project integrates with and references external open-source projects.

## 1) Spec-Kit

- Project: GitHub Spec-Kit
- Repository: https://github.com/github/spec-kit
- Version used by ENMARCHIA: v0.5.0 (`specify-cli`)
- License: MIT

## 2) Squad CLI

- Project: Squad
- Repository: https://github.com/bradygaster/squad
- Version used by ENMARCHIA: v0.9.1 (`@bradygaster/squad-cli`)
- License: MIT

## Notes

- ENMARCHIA is distributed under MIT License.
- ENMARCHIA orchestrates and invokes these tools; it does not vend their source code in this repository.
- If ENMARCHIA starts bundling third-party source files, include the required copyright and license notices for those files.
