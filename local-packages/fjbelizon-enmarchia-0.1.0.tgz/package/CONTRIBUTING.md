# Contributing to Enmarchia

## Development Setup

```bash
git clone https://github.com/fjbelizon/enmarchia
cd enmarchia
npm install
```

## Running Tests

```bash
npm test               # Run all tests once
npm run test:watch     # Watch mode
npm run test:coverage  # With coverage report
```

## Code Structure

See [ARCHITECTURE.md](ARCHITECTURE.md) for a full explanation of all modules.

## Tool Version Policy

Until ENMARCHIA declares a compatible update, development and documentation must target:
- Spec-Kit (`specify-cli`) `v0.5.0`
- Squad CLI (`@bradygaster/squad-cli`) `v0.9.1`

When proposing changes that depend on newer releases, include a compatibility update in the same PR.
Also update THIRD_PARTY_NOTICES.md if third-party references, versions, or license facts change.

## Submitting a PR

1. Fork the repository
2. Create a branch: `git checkout -b feat/my-feature`
3. Write tests for new functionality
4. Ensure all tests pass: `npm test`
5. Open a PR with a clear description

## Reporting Issues

Open an issue with:
- Steps to reproduce
- Expected vs actual behaviour
- Enmarchia version (`enmarchia --version`)
- Node.js version (`node --version`)
