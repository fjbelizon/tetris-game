#!/usr/bin/env node
/**
 * Enmarchia CLI
 * Unified Spec-Kit × Squad Autonomous Development Pipeline
 *
 * Usage: enmarchia <command> [options]
 */

import { Command } from 'commander';
import { resolve } from 'path';
import { createRequire } from 'module';
import { runInit } from './commands/init.js';
import { runBridge } from './commands/bridge.js';
import { runSync } from './commands/sync.js';
import { runLaunch } from './commands/launch.js';
import { runStatus } from './commands/status.js';

const require = createRequire(import.meta.url);
const pkg = require('../package.json') as { version: string; description: string };

const program = new Command();

program
  .name('enmarchia')
  .description(pkg.description)
  .version(pkg.version, '-v, --version', 'Output the current version');

// ---------------------------------------------------------------------------
// enmarchia init
// ---------------------------------------------------------------------------
program
  .command('init')
  .description('Initialize Enmarchia in the current project')
  .option('--force', 'Re-initialize even if already set up', false)
  .option('--with-spec-kit', 'Run Spec-Kit bootstrap (specify init) via ENMARCHIA', false)
  .option('--with-squad', 'Run Squad bootstrap (squad init) via ENMARCHIA', false)
  .option('--with-squad-copilot', 'Also run squad copilot after squad init', false)
  .option('--owner <owner>', 'GitHub owner (user or org)')
  .option('--repo <repo>', 'GitHub repository name')
  .option('-y, --yes', 'Use defaults without interactive prompts', false)
  .action(async (options) => {
    await runInit(resolve(process.cwd()), {
      force: options.force as boolean,
      withSpecKit: options.withSpecKit as boolean,
      withSquad: options.withSquad as boolean,
      withSquadCopilot: options.withSquadCopilot as boolean,
      owner: options.owner as string | undefined,
      repo: options.repo as string | undefined,
      yes: options.yes as boolean,
    });
  });

// ---------------------------------------------------------------------------
// enmarchia bridge
// ---------------------------------------------------------------------------
program
  .command('bridge')
  .description('Convert Spec-Kit tasks to GitHub Issues for Squad to process')
  .option('--feature <id>', 'Bridge only a specific feature (by ID or slug)')
  .option('--dry-run', 'Preview what would be created without making changes', false)
  .option('--force', 'Bridge all tasks even if already annotated', false)
  .option('--skip-sync', 'Skip auto-syncing spec knowledge to Squad agents', false)
  .action(async (options) => {
    await runBridge(resolve(process.cwd()), {
      feature: options.feature as string | undefined,
      dryRun: options.dryRun as boolean,
      force: options.force as boolean,
      skipSync: options.skipSync as boolean,
    });
  });

// ---------------------------------------------------------------------------
// enmarchia sync
// ---------------------------------------------------------------------------
program
  .command('sync')
  .description('Sync Spec-Kit specifications into Squad agent knowledge files')
  .option('--feature <id>', 'Sync only a specific feature (by ID or slug)')
  .option('--agents <names...>', 'Sync only specific agent(s)')
  .action(async (options) => {
    await runSync(resolve(process.cwd()), {
      feature: options.feature as string | undefined,
      agents: options.agents as string[] | undefined,
    });
  });

// ---------------------------------------------------------------------------
// enmarchia launch
// ---------------------------------------------------------------------------
program
  .command('launch')
  .description('Start Squad autonomous watch mode for spec-driven development')
  .option('--interval <minutes>', 'Issue polling interval in minutes (default: from config)', parseInt)
  .option('--agent-cmd <cmd>', 'Custom agent command (default: gh copilot)')
  .option('--copilot-flags <flags>', 'Flags to pass to the agent runner')
  .option('--auth-user <user>', 'GitHub account to use for agent auth')
  .option('--log-file <path>', 'Mirror output to a log file')
  .option(
    '--state-backend <backend>',
    'Persistence backend (in-memory | git-notes | orphan-branch)',
    'git-notes'
  )
  .option('--overnight-start <HH:MM>', 'Pause watch at this time (e.g., 20:00)')
  .option('--overnight-end <HH:MM>', 'Resume watch at this time (e.g., 08:00)')
  .option('--dry-run', 'Show the command that would be run without starting', false)
  .option('--health', 'Check status of running Squad watch process', false)
  .action(async (options) => {
    await runLaunch(resolve(process.cwd()), {
      interval: options.interval as number | undefined,
      agentCmd: options.agentCmd as string | undefined,
      copilotFlags: options.copilotFlags as string | undefined,
      authUser: options.authUser as string | undefined,
      logFile: options.logFile as string | undefined,
      stateBackend: options.stateBackend as 'git-notes' | 'orphan-branch' | 'in-memory',
      overnightStart: options.overnightStart as string | undefined,
      overnightEnd: options.overnightEnd as string | undefined,
      dryRun: options.dryRun as boolean,
      health: options.health as boolean,
    });
  });

// ---------------------------------------------------------------------------
// enmarchia status
// ---------------------------------------------------------------------------
program
  .command('status')
  .description('Show current Enmarchia pipeline status')
  .option('--json', 'Output status as JSON', false)
  .action(async (options) => {
    await runStatus(resolve(process.cwd()), {
      json: options.json as boolean,
    });
  });

// ---------------------------------------------------------------------------
// Parse
// ---------------------------------------------------------------------------
program.parse(process.argv);
