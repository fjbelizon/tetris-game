/**
 * enmarchia sync
 * Synchronizes Spec-Kit specification artifacts into Squad agent knowledge files.
 * Run this when you update specs to ensure agents have fresh context.
 */

import chalk from 'chalk';
import ora from 'ora';
import { loadConfig } from '../config.js';
import { KnowledgeBridge } from '../core/knowledge-bridge.js';
import { SpecKitReader } from '../core/spec-kit-reader.js';

export interface SyncOptions {
  feature?: string;
  agents?: string[];
}

export async function runSync(projectRoot: string, options: SyncOptions): Promise<void> {
  const spinner = ora('Loading configuration...').start();

  let config;
  try {
    config = loadConfig(projectRoot);
  } catch (err) {
    spinner.fail(chalk.red(err instanceof Error ? err.message : String(err)));
    process.exit(1);
  }

  const reader = new SpecKitReader(projectRoot, config.specKit.featuresDir);

  if (!reader.isInitialized()) {
    spinner.fail(chalk.red('specs/ directory not found. Run Spec-Kit first.'));
    process.exit(1);
  }

  const allFeatures = reader.readFeatures();
  const features = options.feature
    ? allFeatures.filter(
        (f) => f.id === options.feature || f.slug === options.feature
      )
    : allFeatures;

  if (features.length === 0) {
    spinner.warn(chalk.yellow('No features found to sync.'));
    return;
  }

  spinner.succeed(`Loaded ${features.length} feature(s) from specs/`);

  // Override agents if specified
  if (options.agents?.length) {
    config.squad.agents = options.agents;
  }

  const bridge = new KnowledgeBridge(projectRoot, config);

  if (!bridge.isSquadInitialized()) {
    console.log('');
    console.log(chalk.yellow('  ⚠  Squad not initialized (.squad/ not found).'));
    console.log(chalk.dim('     Run "squad init" to set up Squad, then re-run "enmarchia sync".'));
    console.log('');
    console.log(chalk.cyan('  Creating Enmarchia spec index anyway...'));
  }

  // Write spec index (works even without Squad)
  const indexSpinner = ora('Writing spec index...').start();
  bridge.writeSpecIndex(features);
  indexSpinner.succeed(chalk.green('Spec index written to .squad/enmarchia-specs.md'));

  // Sync to agent history files
  const syncSpinner = ora('Syncing spec knowledge to Squad agents...').start();
  const result = await bridge.syncFeatures(features);

  if (result.warnings.length > 0) {
    for (const warning of result.warnings) {
      syncSpinner.warn(chalk.yellow(warning));
    }
  } else {
    syncSpinner.succeed(
      chalk.green(
        `Spec knowledge synced: ${result.agentsUpdated} agent(s) updated, ${result.featuresProcessed} feature(s) processed`
      )
    );
  }

  console.log('');
  console.log(chalk.bold.green('  ✓ Sync complete!'));
  console.log('');
  console.log(chalk.dim('  Spec knowledge is now embedded in Squad agent history files.'));
  console.log(chalk.dim('  Agents will use this context when working on spec-driven issues.'));
  console.log('');
}
