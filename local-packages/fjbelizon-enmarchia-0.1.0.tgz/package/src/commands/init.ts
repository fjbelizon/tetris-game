/**
 * enmarchia init
 * Initializes Enmarchia in the current project directory.
 * Optionally also initializes Spec-Kit and/or Squad if not already set up.
 */

import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { join } from 'path';
import { execSync } from 'child_process';
import chalk from 'chalk';
import ora from 'ora';
import prompts from 'prompts';
import { buildDefaultConfig, configExists, saveConfig } from '../config.js';
import { SquadConfigurator } from '../core/squad-configurator.js';

export interface InitOptions {
  force: boolean;
  withSpecKit: boolean;
  withSquad: boolean;
  withSquadCopilot: boolean;
  owner?: string;
  repo?: string;
  yes: boolean;
}

export async function runInit(projectRoot: string, options: InitOptions): Promise<void> {
  console.log('');
  console.log(chalk.bold.cyan('  ┌─────────────────────────────────────────┐'));
  console.log(chalk.bold.cyan('  │  Enmarchia — Autonomous Dev Pipeline     │'));
  console.log(chalk.bold.cyan('  │  Spec-Kit × Squad Integration            │'));
  console.log(chalk.bold.cyan('  └─────────────────────────────────────────┘'));
  console.log('');

  if (configExists(projectRoot) && !options.force) {
    console.log(chalk.yellow('  ⚠  Enmarchia is already initialized here. Use --force to re-initialize.'));
    return;
  }

  // Gather information
  let owner = options.owner;
  let repo = options.repo;
  let projectName = '';

  if (!options.yes) {
    const answers = await prompts([
      {
        type: 'text',
        name: 'projectName',
        message: 'Project name:',
        initial: projectRoot.split(/[/\\]/).pop() ?? 'my-project',
        validate: (v: string) => v.trim().length > 0 || 'Project name is required',
      },
      {
        type: 'text',
        name: 'owner',
        message: 'GitHub owner (user or org):',
        initial: owner ?? '',
        validate: (v: string) => v.trim().length > 0 || 'GitHub owner is required',
      },
      {
        type: 'text',
        name: 'repo',
        message: 'GitHub repository name:',
        initial: repo ?? projectRoot.split(/[/\\]/).pop() ?? '',
        validate: (v: string) => v.trim().length > 0 || 'Repository name is required',
      },
    ]);

    if (!answers.owner) {
      console.log(chalk.red('\n  ✕ Initialization cancelled.'));
      return;
    }

    projectName = answers.projectName as string;
    owner = answers.owner as string;
    repo = answers.repo as string;
  } else {
    projectName = projectRoot.split(/[/\\]/).pop() ?? 'my-project';
    owner = owner ?? 'unknown';
    repo = repo ?? projectName;
  }

  const spinner = ora('Setting up Enmarchia...').start();

  try {
    // Create and save configuration
    const config = buildDefaultConfig(projectName, owner!, repo!);
    saveConfig(projectRoot, config);
    spinner.succeed(chalk.green('Created .enmarchia.json'));

    // Write squad agent instructions
    const configurator = new SquadConfigurator(projectRoot, config);
    configurator.writeAgentInstructions();
    spinner.succeed(chalk.green('Created squad.agent.md'));

    // Write .copilot/enmarchia.md if not already present
    configurator.writeCopilotCustomization();
    spinner.succeed(chalk.green('Created .copilot/enmarchia.md'));

    // Create specs directory scaffold if needed
    if (!existsSync(join(projectRoot, 'specs'))) {
      ensureSpecKitScaffold(projectRoot, projectName);
      spinner.succeed(chalk.green('Created specs/ scaffold'));
    }

    if (options.withSpecKit) {
      runSpecKitInit(projectRoot);
    }

    if (options.withSquad) {
      runSquadInit(projectRoot, options.withSquadCopilot);
    }

    spinner.stop();
    printNextSteps(options.withSpecKit, options.withSquad, options.withSquadCopilot);
  } catch (err) {
    spinner.fail(chalk.red(`Initialization failed: ${err instanceof Error ? err.message : String(err)}`));
    process.exit(1);
  }
}

function runSpecKitInit(projectRoot: string): void {
  const spinner = ora('Initializing Spec-Kit (specify init --here --ai copilot --script ps)...').start();
  try {
    execSync('specify init --here --ai copilot --script ps', {
      cwd: projectRoot,
      stdio: 'pipe',
    });
    spinner.succeed(chalk.green('Spec-Kit initialized'));
  } catch {
    spinner.warn(
      chalk.yellow(
        'Spec-Kit initialization skipped (specify CLI not available or already initialized).'
      )
    );
    console.log(chalk.dim('  Install with: uv tool install specify-cli --from git+https://github.com/github/spec-kit.git@v0.5.0'));
  }
}

function runSquadInit(projectRoot: string, withSquadCopilot: boolean): void {
  const spinner = ora('Initializing Squad (squad init)...').start();
  try {
    execSync('squad init', { cwd: projectRoot, stdio: 'pipe' });
    spinner.succeed(chalk.green('Squad initialized'));
  } catch {
    spinner.warn(chalk.yellow('Squad initialization skipped (squad CLI not available or already initialized).'));
    console.log(chalk.dim('  Install with: npm install -g @bradygaster/squad-cli@0.9.1'));
    return;
  }

  if (withSquadCopilot) {
    const copilotSpinner = ora('Configuring Squad Copilot integration (squad copilot)...').start();
    try {
      execSync('squad copilot', { cwd: projectRoot, stdio: 'pipe' });
      copilotSpinner.succeed(chalk.green('Squad Copilot integration configured'));
    } catch {
      copilotSpinner.warn(chalk.yellow('Squad Copilot setup skipped. You can run "squad copilot" manually.'));
    }
  }
}

function ensureSpecKitScaffold(projectRoot: string, projectName: string): void {
  const specifyDir = join(projectRoot, 'specs');
  if (!existsSync(specifyDir)) {
    mkdirSync(specifyDir, { recursive: true });
  }

  const constitutionPath = join(specifyDir, 'CONSTITUTION.md');
  if (!existsSync(constitutionPath)) {
    writeFileSync(
      constitutionPath,
      [
        `# ${projectName} — Project Constitution`,
        '',
        '> Define your project principles here using Spec-Kit.',
        '> Run `/speckit.constitution` in your AI assistant to generate this properly.',
        '',
        '## Development Principles',
        '',
        '- Write tests for all new code',
        '- Follow existing code conventions',
        '- Security first: validate all inputs, no secrets in code',
        '- Performance matters: measure before optimizing',
        '',
        '## Tech Stack',
        '',
        '> Fill this in using `/speckit.constitution`',
        '',
        '## Definition of Done',
        '',
        '- [ ] Feature implemented per spec',
        '- [ ] Tests written and passing',
        '- [ ] PR opens and references spec issue',
        '- [ ] No new security vulnerabilities',
        '',
      ].join('\n'),
      'utf-8'
    );
  }
}

function printNextSteps(withSpecKit: boolean, withSquad: boolean, withSquadCopilot: boolean): void {
  console.log('');
  console.log(chalk.bold.green('  ✓ Enmarchia initialized successfully!'));
  console.log('');
  console.log(chalk.bold('  Next steps:'));
  console.log('');

  let step = 1;

  if (!withSpecKit) {
    console.log(chalk.cyan(`  ${step++}. Define your project with Spec-Kit:`));
    console.log('     Open your AI assistant and run:');
    console.log(chalk.dim('       /speckit.constitution  →  Define project principles'));
    console.log(chalk.dim('       /speckit.specify       →  Describe what to build'));
    console.log(chalk.dim('       /speckit.plan          →  Create technical plan'));
    console.log(chalk.dim('       /speckit.tasks         →  Generate task list'));
    console.log('');
  } else {
    console.log(chalk.cyan(`  ${step++}. Spec-Kit was initialized via ENMARCHIA.`));
    console.log(chalk.dim('     Continue in Copilot Chat with /speckit.constitution, /speckit.specify, /speckit.plan and /speckit.tasks'));
    console.log('');
  }

  console.log(chalk.cyan(`  ${step++}. Bridge specs to GitHub Issues:`));
  console.log(chalk.dim('     enmarchia bridge'));
  console.log('');

  console.log(chalk.cyan(`  ${step++}. Sync spec knowledge to Squad agents:`));
  console.log(chalk.dim('     enmarchia sync'));
  console.log('');

  if (!withSquad) {
    console.log(chalk.cyan(`  ${step++}. Initialize Squad (if not done):`));
    console.log(chalk.dim('     squad init && squad copilot'));
    console.log('');
  } else if (!withSquadCopilot) {
    console.log(chalk.cyan(`  ${step++}. Optional: configure Squad Copilot integration:`));
    console.log(chalk.dim('     squad copilot'));
    console.log('');
  }

  console.log(chalk.cyan(`  ${step++}. Launch autonomous development:`));
  console.log(chalk.dim('     enmarchia launch'));
  console.log('');

  console.log(chalk.dim('  Check status at any time: enmarchia status'));
  console.log('');
}
