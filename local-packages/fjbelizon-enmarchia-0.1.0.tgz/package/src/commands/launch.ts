/**
 * enmarchia launch
 * Starts Squad's autonomous watch mode with Enmarchia optimized settings.
 * This activates 24/7 autonomous development from spec-driven issues.
 */

import { execSync, spawn } from 'child_process';
import chalk from 'chalk';
import ora from 'ora';
import { loadConfig } from '../config.js';
import { SpecKitReader } from '../core/spec-kit-reader.js';

export interface LaunchOptions {
  interval?: number;
  agentCmd?: string;
  copilotFlags?: string;
  authUser?: string;
  logFile?: string;
  stateBackend?: 'git-notes' | 'orphan-branch' | 'in-memory';
  overnightStart?: string;
  overnightEnd?: string;
  dryRun: boolean;
  health: boolean;
}

export async function runLaunch(projectRoot: string, options: LaunchOptions): Promise<void> {
  // Health check mode
  if (options.health) {
    runHealthCheck();
    return;
  }

  const spinner = ora('Loading configuration...').start();

  let config;
  try {
    config = loadConfig(projectRoot);
  } catch (err) {
    spinner.fail(chalk.red(err instanceof Error ? err.message : String(err)));
    process.exit(1);
  }

  // Verify prerequisites
  spinner.text = 'Checking prerequisites...';
  const checks = await runPreflightChecks(projectRoot, config.specKit.featuresDir, config.squad.dir);

  spinner.stop();

  if (checks.errors.length > 0) {
    console.log('');
    console.log(chalk.red.bold('  ✕ Preflight checks failed:'));
    for (const err of checks.errors) {
      console.log(`    ${chalk.red('•')} ${err}`);
    }
    if (!options.dryRun) {
      process.exit(1);
    }
  }

  if (checks.warnings.length > 0) {
    for (const warn of checks.warnings) {
      console.log(`  ${chalk.yellow('⚠')} ${warn}`);
    }
  }

  const interval = options.interval ?? config.squad.watchInterval;
  const label = config.bridge.labels[0] ?? 'enmarchia';

  // Build squad triage command
  const squadArgs = buildSquadArgs({
    interval,
    agentCmd: options.agentCmd,
    copilotFlags: options.copilotFlags ?? buildDefaultCopilotFlags(label),
    authUser: options.authUser,
    logFile: options.logFile,
    stateBackend: options.stateBackend ?? 'git-notes',
    overnightStart: options.overnightStart,
    overnightEnd: options.overnightEnd,
  });

  const fullCommand = `squad triage ${squadArgs.join(' ')}`;

  console.log('');
  console.log(chalk.bold.cyan('  ┌─────────────────────────────────────────────────────┐'));
  console.log(chalk.bold.cyan('  │  Enmarchia — Launching Autonomous Dev Mode           │'));
  console.log(chalk.bold.cyan('  └─────────────────────────────────────────────────────┘'));
  console.log('');
  console.log(`  ${chalk.bold('Project:')}  ${config.project}`);
  console.log(`  ${chalk.bold('Repo:')}     ${config.github.owner}/${config.github.repo}`);
  console.log(`  ${chalk.bold('Interval:')} every ${interval} minute(s)`);
  console.log(`  ${chalk.bold('Label:')}    ${label}`);
  if (options.overnightStart) {
    console.log(`  ${chalk.bold('Offline:')}  ${options.overnightStart} → ${options.overnightEnd ?? '08:00'}`);
  }
  console.log('');
  console.log(`  ${chalk.dim('Command:')} ${fullCommand}`);
  console.log('');

  if (options.dryRun) {
    console.log(chalk.yellow('  DRY RUN — Squad watch mode would start with the command above.'));
    console.log('');
    return;
  }

  console.log(chalk.bold.green('  Launching Squad autonomous watch mode...'));
  console.log(chalk.dim('  Press Ctrl+C to stop, or create .squad/ralph-stop to stop gracefully.'));
  console.log('');

  // Spawn squad triage as a foreground process
  const proc = spawn('squad', ['triage', '--execute', ...squadArgs], {
    cwd: projectRoot,
    stdio: 'inherit',
    shell: true,
  });

  proc.on('error', (err) => {
    console.error(chalk.red(`\n  Failed to start Squad: ${err.message}`));
    console.error(chalk.dim('  Make sure Squad CLI is installed: npm install -g @bradygaster/squad-cli'));
    process.exit(1);
  });

  proc.on('close', (code) => {
    if (code !== 0) {
      console.log(chalk.yellow(`\n  Squad exited with code ${code ?? 'unknown'}`));
    } else {
      console.log(chalk.green('\n  Squad watch mode stopped gracefully.'));
    }
  });
}

function runHealthCheck(): void {
  try {
    execSync('squad triage --health', { stdio: 'inherit' });
  } catch {
    console.log(chalk.yellow('  Squad watch does not appear to be running.'));
    console.log(chalk.dim('  Start it with: enmarchia launch'));
  }
}

interface PreflightResult {
  errors: string[];
  warnings: string[];
}

async function runPreflightChecks(
  projectRoot: string,
  featuresDir: string,
  squadDir: string
): Promise<PreflightResult> {
  const result: PreflightResult = { errors: [], warnings: [] };
  const { existsSync } = await import('fs');
  const { join } = await import('path');

  // Check Squad CLI is available
  try {
    execSync('squad --version', { stdio: 'pipe' });
  } catch {
    result.errors.push('Squad CLI not found. Install with: npm install -g @bradygaster/squad-cli');
  }

  // Check gh CLI (needed for Copilot agent)
  try {
    execSync('gh auth status', { stdio: 'pipe' });
  } catch {
    result.warnings.push('GitHub CLI not authenticated. Run: gh auth login');
  }

  // Check specs exists
  const reader = new SpecKitReader(projectRoot, featuresDir);
  if (!reader.isInitialized()) {
    result.errors.push('specs/ directory not found. Run Spec-Kit tasks first.');
  } else {
    const pending = reader.readPendingTasks().filter((t) => !t.completed && !t.issueNumber);
    if (pending.length > 0) {
      result.warnings.push(
        `${pending.length} task(s) not yet bridged to GitHub Issues. Run: enmarchia bridge`
      );
    }
  }

  // Check .squad exists
  if (!existsSync(join(projectRoot, squadDir))) {
    result.errors.push('.squad/ directory not found. Run: squad init');
  }

  return result;
}

function buildDefaultCopilotFlags(label: string): string {
  return `--yolo --autopilot --agent squad`;
}

function buildSquadArgs(opts: {
  interval: number;
  agentCmd?: string;
  copilotFlags?: string;
  authUser?: string;
  logFile?: string;
  stateBackend: string;
  overnightStart?: string;
  overnightEnd?: string;
}): string[] {
  const args: string[] = [
    '--execute',
    '--interval', String(opts.interval),
    '--state-backend', opts.stateBackend,
  ];

  if (opts.agentCmd) {
    args.push('--agent-cmd', opts.agentCmd);
  }

  if (opts.copilotFlags) {
    args.push('--copilot-flags', `"${opts.copilotFlags}"`);
  }

  if (opts.authUser) {
    args.push('--auth-user', opts.authUser);
  }

  if (opts.logFile) {
    args.push('--log-file', opts.logFile);
  }

  if (opts.overnightStart) {
    args.push('--overnight-start', opts.overnightStart);
    if (opts.overnightEnd) {
      args.push('--overnight-end', opts.overnightEnd);
    }
  }

  return args;
}
