/**
 * enmarchia status
 * Shows the current state of the Enmarchia pipeline: spec-kit features,
 * squad agents, open/closed issues, and pending tasks.
 */

import chalk from 'chalk';
import ora from 'ora';
import { loadConfig } from '../config.js';
import { IssueCreator } from '../core/issue-creator.js';
import { SpecKitReader } from '../core/spec-kit-reader.js';
import type { EnmarchiaStatus } from '../types.js';
import { existsSync } from 'fs';
import { join, resolve } from 'path';

export interface StatusOptions {
  json: boolean;
}

export async function runStatus(projectRoot: string, options: StatusOptions): Promise<void> {
  const spinner = ora('Gathering status...').start();

  let config;
  try {
    config = loadConfig(projectRoot);
  } catch (err) {
    spinner.fail(chalk.red(err instanceof Error ? err.message : String(err)));
    process.exit(1);
  }

  const reader = new SpecKitReader(projectRoot, config.specKit.featuresDir);
  const features = reader.isInitialized() ? reader.readFeatures() : [];
  const totalTasks = features.reduce((sum, f) => sum + f.tasks.length, 0);
  const completedTasks = features.reduce(
    (sum, f) => sum + f.tasks.filter((t) => t.completed).length,
    0
  );
  const pendingTasks = totalTasks - completedTasks;
  const unbridgedTasks = features.reduce(
    (sum, f) =>
      sum + f.tasks.filter((t) => !t.completed && !t.issueNumber).length,
    0
  );

  // Detect Squad agents
  const squadDir = join(projectRoot, config.squad.dir);
  const agentsDir = join(squadDir, 'agents');
  let agents: string[] = [];
  if (existsSync(agentsDir)) {
    const { readdirSync } = await import('fs');
    agents = readdirSync(agentsDir, { withFileTypes: true })
      .filter((e) => e.isDirectory())
      .map((e) => e.name);
  }

  // Check if Squad watch is running (via .squad/ralph-stop absence and process detection)
  const watchRunning = detectWatchRunning(projectRoot, config.squad.dir);

  // Get GitHub issue counts (only if token is available)
  let openIssues = 0;
  let closedIssues = 0;
  const hasToken = !!(config.github.token);

  if (hasToken) {
    try {
      const creator = new IssueCreator(config);
      const open = await creator.listOpenEnmarchiaIssues();
      openIssues = open.length;
      closedIssues = await creator.countClosedEnmarchiaIssues();
    } catch {
      // Non-fatal — token might not have issues:read scope
    }
  }

  spinner.stop();

  const status: EnmarchiaStatus = {
    project: config.project,
    specKit: {
      initialized: reader.isInitialized(),
      features: features.length,
      totalTasks,
      completedTasks,
      pendingTasks,
    },
    squad: {
      initialized: existsSync(squadDir),
      agents,
      watchRunning,
    },
    bridge: {
      openIssues,
      closedIssues,
      unbridgedTasks,
    },
  };

  if (options.json) {
    console.log(JSON.stringify(status, null, 2));
    return;
  }

  printStatus(status, config.github.owner, config.github.repo, hasToken);
}

function detectWatchRunning(projectRoot: string, squadDir: string): boolean {
  // Heuristic: Squad triage creates a lock/pid file or we can check running processes
  // For now, we check if the stop sentinel exists (if it does, it's stopping)
  const stopFile = join(projectRoot, squadDir, 'ralph-stop');
  // We can't reliably detect PIDs cross-platform without extra deps, so we return false
  // as a conservative default
  return false;
}

function printStatus(
  status: EnmarchiaStatus,
  owner: string,
  repo: string,
  hasToken: boolean
): void {
  const pct =
    status.specKit.totalTasks > 0
      ? Math.round((status.specKit.completedTasks / status.specKit.totalTasks) * 100)
      : 0;

  const bar = buildProgressBar(pct, 20);

  console.log('');
  console.log(chalk.bold.cyan('  ┌─────────────────────────────────────────────────────┐'));
  console.log(chalk.bold.cyan(`  │  Enmarchia Status — ${status.project.padEnd(34)}│`));
  console.log(chalk.bold.cyan('  └─────────────────────────────────────────────────────┘'));
  console.log('');

  // Spec-Kit status
  console.log(chalk.bold('  📋 Spec-Kit'));
  printRow('Initialized', status.specKit.initialized ? chalk.green('✓ Yes') : chalk.red('✕ No'));
  printRow('Features', String(status.specKit.features));
  printRow(
    'Tasks',
    `${status.specKit.completedTasks}/${status.specKit.totalTasks} complete  ${bar}  ${pct}%`
  );
  printRow('Pending', chalk.yellow(String(status.specKit.pendingTasks)));
  console.log('');

  // Squad status
  console.log(chalk.bold('  🤖 Squad'));
  printRow('Initialized', status.squad.initialized ? chalk.green('✓ Yes') : chalk.red('✕ No'));
  printRow(
    'Agents',
    status.squad.agents.length > 0
      ? status.squad.agents.join(', ')
      : chalk.dim('none detected')
  );
  printRow(
    'Watch Running',
    status.squad.watchRunning
      ? chalk.green('✓ Active')
      : chalk.dim('Not running — start with: enmarchia launch')
  );
  console.log('');

  // Bridge status
  console.log(chalk.bold('  🌉 Bridge'));
  printRow('GitHub Repo', `${owner}/${repo}`);

  if (hasToken) {
    printRow('Open Issues', chalk.yellow(String(status.bridge.openIssues)));
    printRow('Closed Issues', chalk.green(String(status.bridge.closedIssues)));
  } else {
    printRow('GitHub Issues', chalk.dim('Set GITHUB_TOKEN to see issue counts'));
  }

  printRow(
    'Unbridged Tasks',
    status.bridge.unbridgedTasks > 0
      ? chalk.yellow(`${status.bridge.unbridgedTasks} task(s) — run: enmarchia bridge`)
      : chalk.green('✓ All bridged')
  );
  console.log('');

  // Pipeline health
  const allGood =
    status.specKit.initialized &&
    status.squad.initialized &&
    status.bridge.unbridgedTasks === 0;

  if (allGood) {
    console.log(chalk.bold.green('  ✓ Pipeline healthy — Squad can work autonomously!'));
  } else {
    console.log(chalk.bold.yellow('  ⚠ Pipeline needs attention:'));
    if (!status.specKit.initialized) {
      console.log(`    ${chalk.yellow('•')} Initialize specs with Enmarchia: enmarchia init --with-spec-kit`);
    }
    if (!status.squad.initialized) {
      console.log(`    ${chalk.yellow('•')} Initialize Squad: squad init`);
    }
    if (status.bridge.unbridgedTasks > 0) {
      console.log(
        `    ${chalk.yellow('•')} Bridge ${status.bridge.unbridgedTasks} task(s): enmarchia bridge`
      );
    }
  }

  console.log('');
}

function printRow(label: string, value: string): void {
  const paddedLabel = `  ${label}:`.padEnd(22);
  console.log(`${chalk.dim(paddedLabel)} ${value}`);
}

function buildProgressBar(pct: number, width: number): string {
  const filled = Math.round((pct / 100) * width);
  const empty = width - filled;
  return chalk.green('█'.repeat(filled)) + chalk.dim('░'.repeat(empty));
}
