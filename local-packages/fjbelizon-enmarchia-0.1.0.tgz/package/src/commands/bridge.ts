/**
 * enmarchia bridge
 * Converts Spec-Kit task checklists into GitHub Issues for Squad to process.
 * This is the core integration command of Enmarchia.
 */

import chalk from 'chalk';
import ora from 'ora';
import { basename } from 'path';
import { loadConfig } from '../config.js';
import { IssueCreator } from '../core/issue-creator.js';
import { KnowledgeBridge } from '../core/knowledge-bridge.js';
import { SpecKitReader } from '../core/spec-kit-reader.js';
import type { BridgeResult, SpecKitTask } from '../types.js';

export interface BridgeOptions {
  feature?: string;
  dryRun: boolean;
  force: boolean;
  skipSync: boolean;
}

export async function runBridge(projectRoot: string, options: BridgeOptions): Promise<void> {
  const spinner = ora('Loading configuration...').start();

  let config;
  try {
    config = loadConfig(projectRoot);
  } catch (err) {
    spinner.fail(chalk.red(err instanceof Error ? err.message : String(err)));
    process.exit(1);
  }

  const reader = new SpecKitReader(projectRoot, config.specKit.featuresDir);

  if (!reader.isInitialized()) {
    spinner.fail(chalk.red('specs/ directory not found. Run Spec-Kit first.'));
    process.exit(1);
  }

  // Load features
  const allFeatures = reader.readFeatures();
  const features = options.feature
    ? allFeatures.filter(
        (f) => f.id === options.feature || f.slug === options.feature
      )
    : allFeatures;

  if (features.length === 0) {
    spinner.warn(
      options.feature
        ? chalk.yellow(`Feature "${options.feature}" not found in specs/`)
        : chalk.yellow('No features found in specs/. Run /speckit.tasks in your AI assistant first.')
    );
    return;
  }

  const totalPending = features.reduce(
    (sum, f) => sum + f.tasks.filter((t) => !t.completed && !t.issueNumber).length,
    0
  );

  if (totalPending === 0) {
    spinner.succeed(chalk.green('All tasks are already bridged or completed. Nothing to do!'));
    return;
  }

  spinner.succeed(
    `Found ${features.length} feature(s) with ${totalPending} task(s) to bridge`
  );

  if (options.dryRun) {
    console.log('');
    console.log(chalk.bold.yellow('  DRY RUN — no issues will be created'));
    console.log('');
    printDryRunPreview(features.flatMap((f) =>
      f.tasks.filter((t) => !t.completed && !t.issueNumber).map((t) => ({ feature: f.name, task: t }))
    ));
    return;
  }

  // Ensure required labels exist
  spinner.start('Ensuring GitHub labels exist...');
  let creator: IssueCreator;
  try {
    creator = new IssueCreator(config);
    await creator.ensureLabels();
    spinner.succeed('GitHub labels ready');
  } catch (err) {
    spinner.fail(chalk.red(`GitHub setup failed: ${err instanceof Error ? err.message : String(err)}`));
    process.exit(1);
  }

  // Bridge each feature
  const totals: BridgeResult = { created: 0, skipped: 0, errors: [], issues: [] };

  for (const feature of features) {
    const featureSpinner = ora(`Bridging feature: ${chalk.bold(feature.name)}...`).start();

    const result = await creator.bridgeFeature(feature, (task: SpecKitTask, issueNumber: number) => {
      featureSpinner.text = `  Creating issue for: ${task.description}`;

      // Annotate tasks.md with issue number
      if (!options.force) {
        const dirName = basename(feature.path);
        reader.annotateTaskWithIssue(dirName, task.description, issueNumber);
      }
    });

    totals.created += result.created;
    totals.skipped += result.skipped;
    totals.errors.push(...result.errors);
    totals.issues.push(...result.issues);

    if (result.errors.length > 0) {
      featureSpinner.warn(
        chalk.yellow(`${feature.name}: ${result.created} created, ${result.errors.length} errors`)
      );
    } else {
      featureSpinner.succeed(
        chalk.green(`${feature.name}: ${result.created} issue(s) created, ${result.skipped} skipped`)
      );
    }
  }

  // Auto-sync spec knowledge if configured and Squad is present
  if (!options.skipSync && config.bridge.autoSync) {
    const knowledgeSyncer = new KnowledgeBridge(projectRoot, config);
    if (knowledgeSyncer.isSquadInitialized()) {
      const syncSpinner = ora('Syncing spec knowledge to Squad agents...').start();
      const syncResult = await knowledgeSyncer.syncFeatures(features);
      knowledgeSyncer.writeSpecIndex(features);

      if (syncResult.warnings.length > 0) {
        syncSpinner.warn(chalk.yellow(syncResult.warnings.join('; ')));
      } else {
        syncSpinner.succeed(
          `Spec knowledge synced to ${syncResult.agentsUpdated} agent(s)`
        );
      }
    }
  }

  // Print summary
  printBridgeSummary(totals);
}

function printDryRunPreview(
  tasks: Array<{ feature: string; task: SpecKitTask }>
): void {
  console.log(chalk.bold('  Issues that would be created:'));
  console.log('');
  for (const { feature, task } of tasks) {
    const indent = '  '.repeat(task.level);
    console.log(`  ${indent}${chalk.cyan('•')} [${feature}] ${task.description}`);
  }
  console.log('');
  console.log(chalk.dim(`  Total: ${tasks.length} issue(s)`));
  console.log('');
  console.log(chalk.dim('  Run without --dry-run to create them.'));
  console.log('');
}

function printBridgeSummary(result: BridgeResult): void {
  console.log('');
  console.log(chalk.bold('  ─── Bridge Summary ───'));
  console.log('');
  console.log(`  ${chalk.green('✓')} Created:  ${chalk.bold(result.created)} issue(s)`);
  console.log(`  ${chalk.gray('○')} Skipped:  ${result.skipped} (already bridged or completed)`);

  if (result.errors.length > 0) {
    console.log(`  ${chalk.red('✕')} Errors:   ${result.errors.length}`);
    console.log('');
    for (const err of result.errors) {
      console.log(`    ${chalk.red('•')} ${err}`);
    }
  }

  if (result.issues.length > 0) {
    console.log('');
    console.log(chalk.bold('  Created Issues:'));
    for (const issue of result.issues) {
      console.log(`    ${chalk.cyan('#' + issue.issueNumber)} ${issue.taskDescription}`);
      console.log(`       ${chalk.dim(issue.issueUrl)}`);
    }
  }

  console.log('');

  if (result.created > 0) {
    console.log(chalk.bold.cyan('  Squad is ready to work! Start autonomous mode with:'));
    console.log(chalk.dim('  enmarchia launch'));
    console.log('');
  }
}
