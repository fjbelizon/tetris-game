/**
 * Issue Creator
 * Creates GitHub Issues from Spec-Kit tasks, embedding full spec context
 * so Squad agents have everything they need to implement without human help.
 */

import { Octokit } from '@octokit/rest';
import type {
  BridgedIssue,
  BridgeResult,
  EnmarchiaConfig,
  GitHubIssuePayload,
  SpecKitFeature,
  SpecKitTask,
} from '../types.js';

export class IssueCreator {
  private readonly octokit: Octokit;
  private readonly config: EnmarchiaConfig;

  constructor(config: EnmarchiaConfig) {
    this.config = config;

    const token = config.github.token;
    if (!token) {
      throw new Error(
        'GitHub token not found. Set GITHUB_TOKEN environment variable or add "token" to your github config.'
      );
    }

    this.octokit = new Octokit({ auth: token });
  }

  /**
   * Bridges all pending tasks from a feature to GitHub Issues.
   * Skips tasks that already have an issue number.
   */
  async bridgeFeature(
    feature: SpecKitFeature,
    onProgress?: (task: SpecKitTask, issueNumber: number) => void
  ): Promise<BridgeResult> {
    const result: BridgeResult = {
      created: 0,
      skipped: 0,
      errors: [],
      issues: [],
    };

    const pendingTasks = feature.tasks.filter((t) => !t.completed && !t.issueNumber);

    for (const task of pendingTasks) {
      try {
        const payload = this.buildIssuePayload(task, feature);
        const issueNumber = await this.createIssue(payload);

        const bridgedIssue: BridgedIssue = {
          taskId: task.id,
          taskDescription: task.description,
          featureName: feature.name,
          issueNumber,
          issueUrl: `https://github.com/${this.config.github.owner}/${this.config.github.repo}/issues/${issueNumber}`,
        };

        result.issues.push(bridgedIssue);
        result.created++;
        onProgress?.(task, issueNumber);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        result.errors.push(`Task "${task.description}": ${message}`);
      }
    }

    // Skipped = already bridged or completed
    result.skipped = feature.tasks.length - pendingTasks.length;

    return result;
  }

  /**
   * Checks if a label already exists in the repo; creates it if it doesn't.
   */
  async ensureLabels(): Promise<void> {
    const labels = this.config.bridge.labels;
    const labelColors: Record<string, string> = {
      enmarchia: '0075ca',
      squad: 'e4e669',
    };

    for (const labelName of labels) {
      try {
        await this.octokit.issues.getLabel({
          owner: this.config.github.owner,
          repo: this.config.github.repo,
          name: labelName,
        });
      } catch {
        // Label doesn't exist, create it
        const color = labelColors[labelName] ?? 'ededed';
        await this.octokit.issues.createLabel({
          owner: this.config.github.owner,
          repo: this.config.github.repo,
          name: labelName,
          color,
          description: `Managed by Enmarchia autonomous development pipeline`,
        });
      }
    }
  }

  /**
   * Returns all open issues created by Enmarchia in the repository.
   */
  async listOpenEnmarchiaIssues(): Promise<Array<{ number: number; title: string; url: string }>> {
    const primaryLabel = this.config.bridge.labels[0] ?? 'enmarchia';

    const issues = await this.octokit.paginate(this.octokit.issues.listForRepo, {
      owner: this.config.github.owner,
      repo: this.config.github.repo,
      labels: primaryLabel,
      state: 'open',
      per_page: 100,
    });

    return issues.map((i) => ({
      number: i.number,
      title: i.title,
      url: i.html_url,
    }));
  }

  /**
   * Returns count of closed Enmarchia issues (implemented tasks).
   */
  async countClosedEnmarchiaIssues(): Promise<number> {
    const primaryLabel = this.config.bridge.labels[0] ?? 'enmarchia';

    const issues = await this.octokit.paginate(this.octokit.issues.listForRepo, {
      owner: this.config.github.owner,
      repo: this.config.github.repo,
      labels: primaryLabel,
      state: 'closed',
      per_page: 100,
    });

    return issues.length;
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  private async createIssue(payload: GitHubIssuePayload): Promise<number> {
    const response = await this.octokit.issues.create({
      owner: this.config.github.owner,
      repo: this.config.github.repo,
      title: payload.title,
      body: payload.body,
      labels: payload.labels,
      assignee: payload.assignee,
    });

    return response.data.number;
  }

  private buildIssuePayload(task: SpecKitTask, feature: SpecKitFeature): GitHubIssuePayload {
    const prefix = this.config.bridge.issuePrefix;
    const title = `${prefix} [${feature.name}] ${task.description}`;

    const body = this.buildIssueBody(task, feature);

    return {
      title,
      body,
      labels: this.config.bridge.labels,
      assignee: this.config.bridge.assignee,
    };
  }

  private buildIssueBody(task: SpecKitTask, feature: SpecKitFeature): string {
    const sections: string[] = [];

    sections.push(`## 📋 Task`);
    sections.push(`**Feature:** ${feature.name} (\`${feature.id}\`)`);
    sections.push(`**Task:** ${task.description}`);
    sections.push('');
    sections.push(
      `> This issue was automatically generated by **Enmarchia** from a Spec-Kit specification.`
    );
    sections.push('> Squad agents should implement this task following the specification below.');
    sections.push('');

    if (feature.spec) {
      sections.push('---');
      sections.push('## 📝 Specification (spec.md)');
      sections.push('');
      sections.push('<details>');
      sections.push('<summary>Click to expand specification</summary>');
      sections.push('');
      sections.push(feature.spec.trim());
      sections.push('');
      sections.push('</details>');
      sections.push('');
    }

    if (feature.plan) {
      sections.push('---');
      sections.push('## 🏗️ Technical Plan (plan.md)');
      sections.push('');
      sections.push('<details>');
      sections.push('<summary>Click to expand technical plan</summary>');
      sections.push('');
      sections.push(feature.plan.trim());
      sections.push('');
      sections.push('</details>');
      sections.push('');
    }

    // Show all tasks for this feature with current task highlighted
    if (feature.tasks.length > 0) {
      sections.push('---');
      sections.push('## ✅ Feature Task List');
      sections.push('');
      for (const t of feature.tasks) {
        const status = t.completed ? '[x]' : '[ ]';
        const highlight = t.id === task.id ? ' ← **This Issue**' : '';
        const indent = '  '.repeat(t.level);
        sections.push(`${indent}- ${status} ${t.description}${highlight}`);
      }
      sections.push('');
    }

    sections.push('---');
    sections.push('## 🤖 Squad Agent Instructions');
    sections.push('');
    sections.push('1. Read the full specification and technical plan above before writing any code.');
    sections.push('2. Follow the project constitution and team conventions.');
    sections.push('3. Write tests before or alongside implementation (spec-driven TDD).');
    sections.push('4. Ensure all acceptance criteria in the spec are met.');
    sections.push('5. Create a PR referencing this issue: `Closes #<issue-number>`.');
    sections.push('');
    sections.push('*Generated by [Enmarchia](https://github.com/fjbelizon/enmarchia)*');

    return sections.join('\n');
  }
}
