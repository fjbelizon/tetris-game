/**
 * Squad Configurator
 * Prepares Squad for autonomous spec-driven work by creating or enhancing
 * the squad.agent.md, team.md, and routing.md files.
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import type { EnmarchiaConfig } from '../types.js';

export class SquadConfigurator {
  private readonly projectRoot: string;
  private readonly squadDir: string;
  private readonly config: EnmarchiaConfig;

  constructor(projectRoot: string, config: EnmarchiaConfig) {
    this.projectRoot = projectRoot;
    this.config = config;
    this.squadDir = join(projectRoot, config.squad.dir);
  }

  /** Returns true if .squad directory exists */
  isInitialized(): boolean {
    return existsSync(this.squadDir);
  }

  /**
  * Writes or updates the squad.agent.md file with Enmarchia aware instructions.
   * This is the primary agent instruction file Squad uses.
   */
  writeAgentInstructions(): void {
    const agentFile = join(this.projectRoot, 'squad.agent.md');
    const content = this.buildAgentInstructions();
    writeFileSync(agentFile, content, 'utf-8');
  }

  /**
   * Updates the Squad team routing to prioritize spec-driven work.
   */
  updateTeamRouting(): void {
    if (!this.isInitialized()) return;

    const routingFile = join(this.squadDir, 'routing.md');
    const existing = existsSync(routingFile) ? readFileSync(routingFile, 'utf-8') : '';

    if (existing.includes('<!-- enmarchia:routing -->')) return;

    const enmarchiaRouting = [
      '',
      '## Enmarchia Issue Routing <!-- enmarchia:routing -->',
      '',
      'Issues labeled `enmarchia` contain Spec-Kit tasks. Route them as follows:',
      '',
      '- **Frontend tasks** (UI, components, styling): → Frontend agent',
      '- **Backend tasks** (API, database, services): → Backend agent',
      '- **Test tasks** (testing, QA, validation): → Tester agent',
      '- **Infrastructure tasks** (CI/CD, deployments, config): → Lead agent',
      '- **General implementation tasks**: → Lead agent to delegate',
      '',
      'All spec-driven issues contain the full specification context in the issue body.',
      'Agents MUST read the spec before implementing.',
      '',
    ].join('\n');

    writeFileSync(routingFile, (existing + enmarchiaRouting).trimEnd() + '\n', 'utf-8');
  }

  /**
   * Creates the .copilot/enmarchia.md customization hint file for VS Code Copilot.
   */
  writeCopilotCustomization(): void {
    const copilotDir = join(this.projectRoot, '.copilot');
    if (!existsSync(copilotDir)) {
      mkdirSync(copilotDir, { recursive: true });
    }

    const filePath = join(copilotDir, 'enmarchia.md');
    if (existsSync(filePath)) return;

    const content = [
      '# Enmarchia Copilot Configuration',
      '',
      'This project uses Enmarchia — a Spec-Kit + Squad autonomous development pipeline.',
      '',
      '## Working with this project',
      '',
      '- All features are defined in `specs/` using Spec-Driven Development',
      '- GitHub Issues tagged `enmarchia` are auto-generated from specifications',
      '- Squad agents work autonomously on those issues 24/7',
      '',
      '## Agent Instructions',
      '',
      '1. **Read the spec first**: Every `enmarchia` issue contains the full `spec.md` in the body',
      '2. **Follow the plan**: The `plan.md` in the issue body defines the technical approach',
      '3. **Test everything**: Spec-driven means every acceptance criterion must have a test',
      '4. **Reference the issue**: All PRs must reference their originating issue',
      '',
    ].join('\n');

    writeFileSync(filePath, content, 'utf-8');
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  private buildAgentInstructions(): string {
    const { project, github, squad } = this.config;

    return [
      `# ${project} — Squad Agent Configuration (Enmarchia)`,
      '',
      `> This project uses **Enmarchia**: a unified Spec-Kit + Squad autonomous development workflow.`,
      `> Specifications are defined in \`specs/\` and issues are auto-generated from them.`,
      '',
      '## Project Context',
      '',
      `**Repository:** ${github.owner}/${github.repo}`,
      `**Team name:** ${squad.teamName}`,
      '',
      '## Enmarchia Autonomous Development Protocol',
      '',
      '### What you are doing',
      'You are implementing a software project that has been fully specified using Spec-Driven Development.',
      'The specifications live in `specs/` and every GitHub Issue tagged `enmarchia` is a task',
      'derived directly from those specs.',
      '',
      '### How to implement a task',
      '',
      '1. **Read the full issue body** — it contains the specification (`spec.md`) and technical plan (`plan.md`)',
      '2. **Check existing code** — understand the codebase before writing anything',
      '3. **Write tests** — every spec item should have at least one test',
      '4. **Implement** — follow the spec, not just the issue title',
      '5. **Review your work** — ensure all acceptance criteria in the spec are met',
      '6. **Open a PR** — title: `feat: [Feature name] <brief description>`, body: `Closes #<issue-number>`',
      '',
      '### Quality bar',
      '',
      '- All existing tests must pass',
      '- New code must have test coverage',
      '- No security vulnerabilities (follow OWASP Top 10)',
      '- Code must match existing conventions and style',
      '',
      '### What to do when blocked',
      '',
      '- Add a comment to the issue describing the blocker',
      '- Label the issue `needs-human-review`',
      '- Move on to the next issue',
      '',
      '### Spec artifacts location',
      '',
      '```',
      'specs/',
      '├── spec-<feature-name>/',
      '│   ├── spec.md        ← What to build (requirements, user stories)',
      '│   ├── plan.md        ← How to build it (tech stack, architecture)',
      '│   └── tasks.md       ← Checklist of tasks (each = one GitHub Issue)',
      '└── CONSTITUTION.md    ← Project principles and guidelines',
      '```',
      '',
      '### Squad spec knowledge',
      '',
      'The `.squad/enmarchia-specs.md` file contains a full index of all specs.',
      'Each agent\'s `.squad/agents/<name>/history.md` contains spec context relevant to their role.',
      '',
    ].join('\n');
  }
}
