/**
 * Spec-Kit Reader
 * Parses specs/ directory structure and extracts features, specifications,
 * plans, and task checklists from Spec-Driven Development artifacts.
 */

import { readdirSync, readFileSync, existsSync, writeFileSync } from 'fs';
import { join } from 'path';
import type { SpecKitFeature, SpecKitTask } from '../types.js';

export class SpecKitReader {
  private readonly specsDir: string;

  constructor(projectRoot: string, featuresDir = 'specs') {
    this.specsDir = join(projectRoot, featuresDir);
  }

  /** Returns true if the specs directory exists in the project */
  isInitialized(): boolean {
    return existsSync(this.specsDir);
  }

  /** Reads all features from the specs directory */
  readFeatures(): SpecKitFeature[] {
    if (!this.isInitialized()) {
      return [];
    }

    const entries = readdirSync(this.specsDir, { withFileTypes: true });
    const featureDirs = entries
      .filter((e) => e.isDirectory() && /^spec-[a-z0-9-]+$/i.test(e.name))
      .sort((a, b) => a.name.localeCompare(b.name));

    return featureDirs.map((dir) => this.readFeature(dir.name));
  }

  /** Reads a single feature by its directory name or slug */
  readFeature(dirName: string): SpecKitFeature {
    const id = dirName;
    const slug = dirName.replace(/^spec-/i, '');
    const name = slug
      .replace(/-/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());

    const featurePath = join(this.specsDir, dirName);

    const specFile = join(featurePath, 'spec.md');
    const planFile = join(featurePath, 'plan.md');
    const tasksFile = join(featurePath, 'tasks.md');

    const tasks = existsSync(tasksFile)
      ? this.parseTasks(readFileSync(tasksFile, 'utf-8'), id, name)
      : [];

    return {
      id,
      name,
      slug,
      path: featurePath,
      spec: existsSync(specFile) ? readFileSync(specFile, 'utf-8') : undefined,
      plan: existsSync(planFile) ? readFileSync(planFile, 'utf-8') : undefined,
      tasks,
    };
  }

  /** Returns only pending (uncompleted) tasks across all features */
  readPendingTasks(): SpecKitTask[] {
    return this.readFeatures()
      .flatMap((f) => f.tasks)
      .filter((t) => !t.completed);
  }

  /**
   * Updates tasks.md for a feature to add issue number references.
   * Modifies lines matching `- [ ] <description>` to append `(#<issueNumber>)`.
   */
  annotateTaskWithIssue(
    featureDirName: string,
    taskDescription: string,
    issueNumber: number
  ): void {
    const featurePath = join(this.specsDir, featureDirName);
    const tasksFile = join(featurePath, 'tasks.md');

    if (!existsSync(tasksFile)) return;

    const content = readFileSync(tasksFile, 'utf-8');
    const escapedDesc = taskDescription.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const pattern = new RegExp(
      `^(\\s*-\\s*\\[[ ]\\]\\s*)${escapedDesc}(\\s*)$`,
      'gm'
    );
    const updated = content.replace(pattern, `$1${taskDescription} (#${issueNumber})$2`);
    writeFileSync(tasksFile, updated, 'utf-8');
  }

  /**
   * Reads the constitution file if it exists.
   */
  readConstitution(constitutionFile = 'specs/CONSTITUTION.md'): string | undefined {
    const parts = constitutionFile.split('/');
    const filePath = join(this.specsDir, '..', ...parts);
    return existsSync(filePath) ? readFileSync(filePath, 'utf-8') : undefined;
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  private parseTasks(
    content: string,
    featureId: string,
    featureName: string
  ): SpecKitTask[] {
    const tasks: SpecKitTask[] = [];
    const lines = content.split('\n');
    let taskIndex = 0;

    for (const line of lines) {
      // Match markdown checkbox items at any indentation level
      const match = line.match(/^(\s*)-\s*\[([ xX])\]\s+(.+)$/);
      if (!match) continue;

      const [, indent, checked, rawDescription] = match;
      const level = Math.floor((indent?.length ?? 0) / 2);

      // Extract existing issue reference if present, e.g. "(#42)"
      const issueMatch = rawDescription.match(/\(#(\d+)\)\s*$/);
      const description = rawDescription.replace(/\s*\(#\d+\)\s*$/, '').trim();

      tasks.push({
        id: `${featureId}-${++taskIndex}`,
        featureId,
        featureName,
        description,
        completed: checked.toLowerCase() === 'x',
        level,
        issueNumber: issueMatch ? parseInt(issueMatch[1], 10) : undefined,
      });
    }

    return tasks;
  }
}
