/**
 * Enmarchia Public API
 * Exports core modules for programmatic use.
 */

export { SpecKitReader } from './core/spec-kit-reader.js';
export { IssueCreator } from './core/issue-creator.js';
export { KnowledgeBridge } from './core/knowledge-bridge.js';
export { SquadConfigurator } from './core/squad-configurator.js';
export { loadConfig, saveConfig, buildDefaultConfig, configExists } from './config.js';
export type {
  EnmarchiaConfig,
  SpecKitFeature,
  SpecKitTask,
  BridgeResult,
  BridgedIssue,
  SyncResult,
  EnmarchiaStatus,
} from './types.js';
