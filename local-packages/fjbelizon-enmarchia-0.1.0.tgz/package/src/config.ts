/**
 * Enmarchia Configuration Manager
 * Reads, validates and writes .enmarchia.json configuration.
 */

import { existsSync, readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { z } from 'zod';
import type { EnmarchiaConfig } from './types.js';

const ConfigSchema = z.object({
  project: z.string().min(1),
  github: z.object({
    owner: z.string().min(1),
    repo: z.string().min(1),
    token: z.string().optional(),
  }),
  specKit: z
    .object({
      featuresDir: z.string().default('specs'),
      constitutionFile: z.string().default('specs/CONSTITUTION.md'),
    })
    .default({}),
  squad: z
    .object({
      dir: z.string().default('.squad'),
      teamName: z.string().default('Enmarchia Squad'),
      watchInterval: z.number().int().positive().default(10),
      agents: z.array(z.string()).default([]),
    })
    .default({}),
  bridge: z
    .object({
      labels: z.array(z.string()).default(['enmarchia', 'squad']),
      assignee: z.string().optional(),
      autoSync: z.boolean().default(true),
      issuePrefix: z.string().default('[Enmarchia]'),
    })
    .default({}),
});

export const CONFIG_FILENAME = '.enmarchia.json';

export function resolveConfigPath(projectRoot: string): string {
  return join(projectRoot, CONFIG_FILENAME);
}

export function configExists(projectRoot: string): boolean {
  return existsSync(resolveConfigPath(projectRoot));
}

export function loadConfig(projectRoot: string): EnmarchiaConfig {
  const configPath = resolveConfigPath(projectRoot);

  if (!existsSync(configPath)) {
    throw new Error(
      `Enmarchia configuration not found at ${configPath}.\n` +
      `Run "enmarchia init" to initialize the project.`
    );
  }

  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(configPath, 'utf-8'));
  } catch {
    throw new Error(`Failed to parse ${CONFIG_FILENAME}. Ensure it is valid JSON.`);
  }

  const result = ConfigSchema.safeParse(raw);
  if (!result.success) {
    const issues = result.error.issues.map((i) => `  • ${i.path.join('.')}: ${i.message}`).join('\n');
    throw new Error(`Invalid configuration in ${CONFIG_FILENAME}:\n${issues}`);
  }

  // Prefer GITHUB_TOKEN env var over config file value (avoids committing secrets)
  const config = result.data as EnmarchiaConfig;
  if (!config.github.token) {
    config.github.token = process.env['GITHUB_TOKEN'] ?? process.env['GH_TOKEN'];
  }

  return config;
}

export function saveConfig(projectRoot: string, config: EnmarchiaConfig): void {
  const configPath = resolveConfigPath(projectRoot);
  // Strip the token before writing to disk — it should live in env vars only
  const { github, ...rest } = config;
  const { token: _token, ...githubWithoutToken } = github;
  const safeConfig = { ...rest, github: githubWithoutToken };
  writeFileSync(configPath, JSON.stringify(safeConfig, null, 2) + '\n', 'utf-8');
}

export function buildDefaultConfig(
  projectName: string,
  githubOwner: string,
  githubRepo: string
): EnmarchiaConfig {
  return ConfigSchema.parse({
    project: projectName,
    github: { owner: githubOwner, repo: githubRepo },
  }) as EnmarchiaConfig;
}
