/**
 * Enmarchia Core Types
 * Shared type definitions for the Spec-Kit → Squad integration bridge.
 */

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

export interface EnmarchiaConfig {
  /** Human-readable project name */
  project: string;
  /** GitHub repository settings for Issue creation */
  github: {
    owner: string;
    repo: string;
    /** Personal access token — can also be set via GITHUB_TOKEN env var */
    token?: string;
  };
  /** Spec-Kit integration settings */
  specKit: {
    /** Directory where specs are stored (default: "specs") */
    featuresDir: string;
    /** Path to constitution file (default: "specs/CONSTITUTION.md") */
    constitutionFile: string;
  };
  /** Squad integration settings */
  squad: {
    /** Squad state directory (default: ".squad") */
    dir: string;
    /** Team name for display purposes */
    teamName: string;
    /** Watch mode polling interval in minutes (default: 10) */
    watchInterval: number;
    /** List of Squad agent names to receive spec knowledge */
    agents: string[];
  };
  /** Bridge operation settings */
  bridge: {
    /** GitHub labels to apply to bridged issues */
    labels: string[];
    /** Optional GitHub user to assign issues to */
    assignee?: string;
    /** Whether to auto-sync spec knowledge on bridge */
    autoSync: boolean;
    /** Prefix for issue titles to identify Enmarchia issues */
    issuePrefix: string;
  };
}

// ---------------------------------------------------------------------------
// Spec-Kit Artifacts
// ---------------------------------------------------------------------------

export interface SpecKitFeature {
  /** Feature identifier from folder name (e.g., "spec-user-auth") */
  id: string;
  /** Human-readable feature name */
  name: string;
  /** URL-friendly slug derived from folder name (e.g., "user-auth") */
  slug: string;
  /** Absolute path to feature directory */
  path: string;
  /** Raw markdown content of spec.md */
  spec?: string;
  /** Raw markdown content of plan.md */
  plan?: string;
  /** Parsed task list from tasks.md */
  tasks: SpecKitTask[];
}

export interface SpecKitTask {
  /** Unique task identifier (featureId-index) */
  id: string;
  /** Parent feature ID */
  featureId: string;
  /** Feature name for context */
  featureName: string;
  /** Task description text */
  description: string;
  /** Whether the task checkbox is checked */
  completed: boolean;
  /** Indentation level (0 = top-level, 1+ = sub-task) */
  level: number;
  /** GitHub Issue number if already bridged */
  issueNumber?: number;
}

// ---------------------------------------------------------------------------
// Bridge Results
// ---------------------------------------------------------------------------

export interface BridgeResult {
  /** Number of issues successfully created */
  created: number;
  /** Number of tasks skipped (already bridged or completed) */
  skipped: number;
  /** Errors encountered during bridging */
  errors: string[];
  /** Details of created issues */
  issues: BridgedIssue[];
}

export interface BridgedIssue {
  taskId: string;
  taskDescription: string;
  featureName: string;
  issueNumber: number;
  issueUrl: string;
}

// ---------------------------------------------------------------------------
// Sync Results
// ---------------------------------------------------------------------------

export interface SyncResult {
  /** Number of agents updated with spec knowledge */
  agentsUpdated: number;
  /** Number of features synced */
  featuresProcessed: number;
  /** Any warnings or non-fatal issues */
  warnings: string[];
}

// ---------------------------------------------------------------------------
// Status Report
// ---------------------------------------------------------------------------

export interface EnmarchiaStatus {
  project: string;
  specKit: SpecKitStatus;
  squad: SquadStatus;
  bridge: BridgeStatus;
}

export interface SpecKitStatus {
  initialized: boolean;
  features: number;
  totalTasks: number;
  completedTasks: number;
  pendingTasks: number;
}

export interface SquadStatus {
  initialized: boolean;
  agents: string[];
  watchRunning: boolean;
}

export interface BridgeStatus {
  lastRun?: string;
  openIssues: number;
  closedIssues: number;
  unbridgedTasks: number;
}

// ---------------------------------------------------------------------------
// GitHub Types
// ---------------------------------------------------------------------------

export interface GitHubIssuePayload {
  title: string;
  body: string;
  labels: string[];
  assignee?: string;
}
