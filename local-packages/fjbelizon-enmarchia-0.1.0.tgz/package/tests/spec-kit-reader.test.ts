/**
 * Tests for SpecKitReader
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { SpecKitReader } from '../src/core/spec-kit-reader.js';

describe('SpecKitReader', () => {
  let tempDir: string;

  beforeEach(() => {
    tempDir = mkdtempSync(join(tmpdir(), 'enmarchia-test-'));
  });

  afterEach(() => {
    rmSync(tempDir, { recursive: true, force: true });
  });

  // ---------------------------------------------------------------------------
  // isInitialized
  // ---------------------------------------------------------------------------
  describe('isInitialized()', () => {
    it('returns false when specs does not exist', () => {
      const reader = new SpecKitReader(tempDir);
      expect(reader.isInitialized()).toBe(false);
    });

    it('returns true when specs exists', () => {
      mkdirSync(join(tempDir, 'specs'));
      const reader = new SpecKitReader(tempDir);
      expect(reader.isInitialized()).toBe(true);
    });
  });

  // ---------------------------------------------------------------------------
  // readFeatures
  // ---------------------------------------------------------------------------
  describe('readFeatures()', () => {
    it('returns empty array when specs does not exist', () => {
      const reader = new SpecKitReader(tempDir);
      expect(reader.readFeatures()).toEqual([]);
    });

    it('returns empty array when specs has no feature directories', () => {
      mkdirSync(join(tempDir, 'specs'));
      const reader = new SpecKitReader(tempDir);
      expect(reader.readFeatures()).toEqual([]);
    });

    it('ignores directories without the spec- prefix', () => {
      mkdirSync(join(tempDir, 'specs'));
      mkdirSync(join(tempDir, 'specs', 'shared-utils'));
      const reader = new SpecKitReader(tempDir);
      expect(reader.readFeatures()).toHaveLength(0);
    });

    it('reads a single feature directory correctly', () => {
      const specDir = join(tempDir, 'specs', 'spec-user-auth');
      mkdirSync(specDir, { recursive: true });
      writeFileSync(join(specDir, 'spec.md'), '# User Auth Spec\n\nUsers can log in.', 'utf-8');
      writeFileSync(join(specDir, 'plan.md'), '# Plan\n\nUse JWT tokens.', 'utf-8');
      writeFileSync(
        join(specDir, 'tasks.md'),
        '## Tasks\n\n- [ ] Create login API\n- [x] Setup database\n',
        'utf-8'
      );

      const reader = new SpecKitReader(tempDir);
      const features = reader.readFeatures();

      expect(features).toHaveLength(1);
      expect(features[0]!.id).toBe('spec-user-auth');
      expect(features[0]!.slug).toBe('user-auth');
      expect(features[0]!.name).toBe('User Auth');
      expect(features[0]!.spec).toContain('Users can log in');
      expect(features[0]!.plan).toContain('JWT tokens');
      expect(features[0]!.tasks).toHaveLength(2);
    });

    it('reads multiple features sorted by id', () => {
      mkdirSync(join(tempDir, 'specs', 'spec-user-auth'), { recursive: true });
      mkdirSync(join(tempDir, 'specs', 'spec-billing'), { recursive: true });

      const reader = new SpecKitReader(tempDir);
      const features = reader.readFeatures();

      expect(features).toHaveLength(2);
      expect(features[0]!.id).toBe('spec-billing');
      expect(features[1]!.id).toBe('spec-user-auth');
    });

    it('handles feature without spec, plan, or tasks files', () => {
      mkdirSync(join(tempDir, 'specs', 'spec-user-auth'), { recursive: true });
      const reader = new SpecKitReader(tempDir);
      const features = reader.readFeatures();

      expect(features).toHaveLength(1);
      expect(features[0]!.spec).toBeUndefined();
      expect(features[0]!.plan).toBeUndefined();
      expect(features[0]!.tasks).toEqual([]);
    });
  });

  // ---------------------------------------------------------------------------
  // Task parsing
  // ---------------------------------------------------------------------------
  describe('task parsing', () => {
    function createFeatureWithTasks(tasks: string): void {
      const specDir = join(tempDir, 'specs', 'spec-user-auth');
      mkdirSync(specDir, { recursive: true });
      writeFileSync(join(specDir, 'tasks.md'), tasks, 'utf-8');
    }

    it('parses uncompleted tasks correctly', () => {
      createFeatureWithTasks('- [ ] Build login form\n- [ ] Add validation\n');
      const reader = new SpecKitReader(tempDir);
      const tasks = reader.readFeatures()[0]!.tasks;

      expect(tasks).toHaveLength(2);
      expect(tasks[0]!.completed).toBe(false);
      expect(tasks[0]!.description).toBe('Build login form');
      expect(tasks[1]!.completed).toBe(false);
    });

    it('parses completed tasks correctly', () => {
      createFeatureWithTasks('- [x] Setup project\n- [X] Init database\n');
      const reader = new SpecKitReader(tempDir);
      const tasks = reader.readFeatures()[0]!.tasks;

      expect(tasks[0]!.completed).toBe(true);
      expect(tasks[1]!.completed).toBe(true);
    });

    it('extracts existing issue numbers from annotations', () => {
      createFeatureWithTasks('- [ ] Build API (#42)\n- [ ] Write tests\n');
      const reader = new SpecKitReader(tempDir);
      const tasks = reader.readFeatures()[0]!.tasks;

      expect(tasks[0]!.issueNumber).toBe(42);
      expect(tasks[0]!.description).toBe('Build API');
      expect(tasks[1]!.issueNumber).toBeUndefined();
    });

    it('handles indented subtasks and assigns correct level', () => {
      createFeatureWithTasks(
        '- [ ] Main task\n  - [ ] Sub-task 1\n    - [ ] Deep task\n'
      );
      const reader = new SpecKitReader(tempDir);
      const tasks = reader.readFeatures()[0]!.tasks;

      expect(tasks[0]!.level).toBe(0);
      expect(tasks[1]!.level).toBe(1);
      expect(tasks[2]!.level).toBe(2);
    });

    it('ignores non-checkbox lines', () => {
      createFeatureWithTasks('# Tasks\n\nSome header\n- [ ] Real task\n\nFooter text\n');
      const reader = new SpecKitReader(tempDir);
      const tasks = reader.readFeatures()[0]!.tasks;

      expect(tasks).toHaveLength(1);
      expect(tasks[0]!.description).toBe('Real task');
    });

    it('assigns unique ids per feature', () => {
      createFeatureWithTasks('- [ ] Task A\n- [ ] Task B\n- [ ] Task C\n');
      const reader = new SpecKitReader(tempDir);
      const tasks = reader.readFeatures()[0]!.tasks;

      const ids = tasks.map((t) => t.id);
      expect(new Set(ids).size).toBe(3);
    });
  });

  // ---------------------------------------------------------------------------
  // readPendingTasks
  // ---------------------------------------------------------------------------
  describe('readPendingTasks()', () => {
    it('returns only uncompleted tasks without issue numbers', () => {
      const specDir1 = join(tempDir, 'specs', 'spec-user-auth');
      const specDir2 = join(tempDir, 'specs', 'spec-billing');
      mkdirSync(specDir1, { recursive: true });
      mkdirSync(specDir2, { recursive: true });

      writeFileSync(
        join(specDir1, 'tasks.md'),
        '- [x] Done task\n- [ ] Pending task\n- [ ] Bridged task (#5)\n',
        'utf-8'
      );
      writeFileSync(join(specDir2, 'tasks.md'), '- [ ] Another pending\n', 'utf-8');

      const reader = new SpecKitReader(tempDir);
      const pending = reader.readPendingTasks();

      // Should return uncompleted tasks (including bridged ones — they're still pending to complete)
      expect(pending.length).toBeGreaterThanOrEqual(3);
      expect(pending.some((t) => t.description === 'Done task')).toBe(false);
      expect(pending.some((t) => t.description === 'Pending task')).toBe(true);
      expect(pending.some((t) => t.description === 'Another pending')).toBe(true);
    });
  });

  // ---------------------------------------------------------------------------
  // annotateTaskWithIssue
  // ---------------------------------------------------------------------------
  describe('annotateTaskWithIssue()', () => {
    it('adds issue number annotation to a matching task line', () => {
      const specDir = join(tempDir, 'specs', 'spec-user-auth');
      mkdirSync(specDir, { recursive: true });
      writeFileSync(
        join(specDir, 'tasks.md'),
        '- [ ] Build login form\n- [ ] Add validation\n',
        'utf-8'
      );

      const reader = new SpecKitReader(tempDir);
        reader.annotateTaskWithIssue('spec-user-auth', 'Build login form', 99);

      const { readFileSync } = require('fs');
      const updated = readFileSync(join(specDir, 'tasks.md'), 'utf-8') as string;
      expect(updated).toContain('Build login form (#99)');
      expect(updated).toContain('- [ ] Add validation');
    });

    it('does nothing if the file does not exist', () => {
      const reader = new SpecKitReader(tempDir);
      // Should not throw
      expect(() => reader.annotateTaskWithIssue('spec-missing', 'Task', 1)).not.toThrow();
    });
  });
});
