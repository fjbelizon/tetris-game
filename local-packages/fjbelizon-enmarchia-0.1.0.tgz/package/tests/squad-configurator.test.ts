/**
 * Tests for SquadConfigurator
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { SquadConfigurator } from '../src/core/squad-configurator.js';
import { buildDefaultConfig } from '../src/config.js';

describe('SquadConfigurator', () => {
  let tempDir: string;

  beforeEach(() => {
    tempDir = mkdtempSync(join(tmpdir(), 'enmarchia-squad-test-'));
  });

  afterEach(() => {
    rmSync(tempDir, { recursive: true, force: true });
  });

  // ---------------------------------------------------------------------------
  // isInitialized
  // ---------------------------------------------------------------------------
  describe('isInitialized()', () => {
    it('returns false when .squad does not exist', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      expect(configurator.isInitialized()).toBe(false);
    });

    it('returns true when .squad exists', () => {
      mkdirSync(join(tempDir, '.squad'));
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      expect(configurator.isInitialized()).toBe(true);
    });
  });

  // ---------------------------------------------------------------------------
  // writeAgentInstructions
  // ---------------------------------------------------------------------------
  describe('writeAgentInstructions()', () => {
    it('creates squad.agent.md in project root', () => {
      const config = buildDefaultConfig('My Project', 'acme', 'my-repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.writeAgentInstructions();

      const agentFile = join(tempDir, 'squad.agent.md');
      expect(existsSync(agentFile)).toBe(true);
    });

    it('includes project name in agent instructions', () => {
      const config = buildDefaultConfig('Awesome App', 'acme', 'awesome-repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.writeAgentInstructions();

      const content = readFileSync(join(tempDir, 'squad.agent.md'), 'utf-8');
      expect(content).toContain('Awesome App');
      expect(content).toContain('acme/awesome-repo');
    });

    it('mentions Enmarchia and Spec-Kit in instructions', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.writeAgentInstructions();

      const content = readFileSync(join(tempDir, 'squad.agent.md'), 'utf-8');
      expect(content).toContain('Enmarchia');
      expect(content).toContain('Spec-Driven Development');
      expect(content).toContain('specs/');
    });

    it('includes squad agent protocol steps', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.writeAgentInstructions();

      const content = readFileSync(join(tempDir, 'squad.agent.md'), 'utf-8');
      expect(content).toContain('spec.md');
      expect(content).toContain('plan.md');
      expect(content).toContain('Closes #');
    });
  });

  // ---------------------------------------------------------------------------
  // updateTeamRouting
  // ---------------------------------------------------------------------------
  describe('updateTeamRouting()', () => {
    it('does nothing when Squad is not initialized', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      // Should not throw
      expect(() => configurator.updateTeamRouting()).not.toThrow();
    });

    it('creates routing content when .squad exists but routing.md does not', () => {
      mkdirSync(join(tempDir, '.squad'));
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.updateTeamRouting();

      const routingFile = join(tempDir, '.squad', 'routing.md');
      expect(existsSync(routingFile)).toBe(true);
      const content = readFileSync(routingFile, 'utf-8');
      expect(content).toContain('Enmarchia Issue Routing');
      expect(content).toContain('enmarchia');
    });

    it('appends routing to existing routing.md', () => {
      mkdirSync(join(tempDir, '.squad'));
      const routingFile = join(tempDir, '.squad', 'routing.md');
      const { writeFileSync } = require('fs');
      writeFileSync(routingFile, '# Routing\n\nDefault routing rules.\n', 'utf-8');

      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.updateTeamRouting();

      const content = readFileSync(routingFile, 'utf-8');
      expect(content).toContain('Default routing rules');
      expect(content).toContain('Enmarchia Issue Routing');
    });

    it('does not duplicate routing section on second call', () => {
      mkdirSync(join(tempDir, '.squad'));
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);

      configurator.updateTeamRouting();
      configurator.updateTeamRouting();

      const content = readFileSync(join(tempDir, '.squad', 'routing.md'), 'utf-8');
      const count = (content.match(/Enmarchia Issue Routing/g) ?? []).length;
      expect(count).toBe(1);
    });
  });

  // ---------------------------------------------------------------------------
  // writeCopilotCustomization
  // ---------------------------------------------------------------------------
  describe('writeCopilotCustomization()', () => {
    it('creates .copilot/enmarchia.md', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.writeCopilotCustomization();

      expect(existsSync(join(tempDir, '.copilot', 'enmarchia.md'))).toBe(true);
    });

    it('does not overwrite existing file', () => {
      const copilotDir = join(tempDir, '.copilot');
      mkdirSync(copilotDir, { recursive: true });
      const filePath = join(copilotDir, 'enmarchia.md');
      const { writeFileSync } = require('fs');
      writeFileSync(filePath, '# Custom content\n', 'utf-8');

      const config = buildDefaultConfig('test', 'owner', 'repo');
      const configurator = new SquadConfigurator(tempDir, config);
      configurator.writeCopilotCustomization();

      const content = readFileSync(filePath, 'utf-8');
      expect(content).toBe('# Custom content\n');
    });
  });
});
