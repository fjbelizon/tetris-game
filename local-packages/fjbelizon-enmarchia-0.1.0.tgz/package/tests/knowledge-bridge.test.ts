/**
 * Tests for KnowledgeBridge
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { KnowledgeBridge } from '../src/core/knowledge-bridge.js';
import { buildDefaultConfig } from '../src/config.js';
import type { SpecKitFeature } from '../src/types.js';

function makeFeature(overrides: Partial<SpecKitFeature> = {}): SpecKitFeature {
  return {
    id: '001',
    name: 'User Auth',
    slug: 'user-auth',
    path: '/tmp/test/specs/spec-user-auth',
    spec: '# Spec\n\nUsers can log in with email and password.',
    plan: '# Plan\n\nUse JWT with bcrypt.',
    tasks: [
      {
        id: '001-1',
        featureId: '001',
        featureName: 'User Auth',
        description: 'Create login endpoint',
        completed: false,
        level: 0,
        issueNumber: 42,
      },
      {
        id: '001-2',
        featureId: '001',
        featureName: 'User Auth',
        description: 'Write auth tests',
        completed: true,
        level: 0,
      },
    ],
    ...overrides,
  };
}

describe('KnowledgeBridge', () => {
  let tempDir: string;

  beforeEach(() => {
    tempDir = mkdtempSync(join(tmpdir(), 'enmarchia-kb-test-'));
  });

  afterEach(() => {
    rmSync(tempDir, { recursive: true, force: true });
  });

  // ---------------------------------------------------------------------------
  // isSquadInitialized
  // ---------------------------------------------------------------------------
  describe('isSquadInitialized()', () => {
    it('returns false when .squad does not exist', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const bridge = new KnowledgeBridge(tempDir, config);
      expect(bridge.isSquadInitialized()).toBe(false);
    });

    it('returns true when .squad exists', () => {
      mkdirSync(join(tempDir, '.squad'));
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const bridge = new KnowledgeBridge(tempDir, config);
      expect(bridge.isSquadInitialized()).toBe(true);
    });
  });

  // ---------------------------------------------------------------------------
  // writeSpecIndex
  // ---------------------------------------------------------------------------
  describe('writeSpecIndex()', () => {
    it('creates the spec index file in .squad/', () => {
      mkdirSync(join(tempDir, '.squad'));
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const bridge = new KnowledgeBridge(tempDir, config);
      const features = [makeFeature()];

      bridge.writeSpecIndex(features);

      const indexPath = join(tempDir, '.squad', 'enmarchia-specs.md');
      const content = readFileSync(indexPath, 'utf-8');
      expect(content).toContain('Enmarchia Specification Index');
      expect(content).toContain('User Auth');
      expect(content).toContain('Create login endpoint');
    });

    it('includes task completion stats', () => {
      mkdirSync(join(tempDir, '.squad'));
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const bridge = new KnowledgeBridge(tempDir, config);
      const features = [makeFeature()];

      bridge.writeSpecIndex(features);

      const content = readFileSync(join(tempDir, '.squad', 'enmarchia-specs.md'), 'utf-8');
      expect(content).toContain('1/2 complete');
    });

    it('does nothing when Squad is not initialized', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const bridge = new KnowledgeBridge(tempDir, config);
      // Should not throw
      expect(() => bridge.writeSpecIndex([makeFeature()])).not.toThrow();
    });
  });

  // ---------------------------------------------------------------------------
  // syncFeatures
  // ---------------------------------------------------------------------------
  describe('syncFeatures()', () => {
    it('returns warning when Squad is not initialized', async () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const bridge = new KnowledgeBridge(tempDir, config);
      const result = await bridge.syncFeatures([makeFeature()]);

      expect(result.warnings).toHaveLength(1);
      expect(result.warnings[0]).toContain('Squad not initialized');
      expect(result.agentsUpdated).toBe(0);
    });

    it('returns warning when no agents configured or detected', async () => {
      mkdirSync(join(tempDir, '.squad'));
      const config = buildDefaultConfig('test', 'owner', 'repo');
      const bridge = new KnowledgeBridge(tempDir, config);
      const result = await bridge.syncFeatures([makeFeature()]);

      expect(result.warnings).toHaveLength(1);
      expect(result.warnings[0]).toContain('No Squad agents');
    });

    it('creates agent history file with spec content', async () => {
      const squadAgentDir = join(tempDir, '.squad', 'agents', 'backend');
      mkdirSync(squadAgentDir, { recursive: true });

      const config = buildDefaultConfig('test', 'owner', 'repo');
      config.squad.agents = ['backend'];
      const bridge = new KnowledgeBridge(tempDir, config);
      const result = await bridge.syncFeatures([makeFeature()]);

      expect(result.agentsUpdated).toBe(1);

      const historyPath = join(squadAgentDir, 'history.md');
      const content = readFileSync(historyPath, 'utf-8');
      expect(content).toContain('Enmarchia Project Specifications');
      expect(content).toContain('User Auth');
      expect(content).toContain('Users can log in with email and password');
    });

    it('updates existing agent history without duplicating the section', async () => {
      const squadAgentDir = join(tempDir, '.squad', 'agents', 'backend');
      mkdirSync(squadAgentDir, { recursive: true });

      const historyPath = join(squadAgentDir, 'history.md');
      writeFileSync(historyPath, '# Backend History\n\nI know TypeScript well.\n', 'utf-8');

      const config = buildDefaultConfig('test', 'owner', 'repo');
      config.squad.agents = ['backend'];
      const bridge = new KnowledgeBridge(tempDir, config);

      await bridge.syncFeatures([makeFeature()]);
      await bridge.syncFeatures([makeFeature()]); // run twice

      const content = readFileSync(historyPath, 'utf-8');
      // Verify section appears exactly once
      const markerCount = (content.match(/<!-- enmarchia:specs:start -->/g) ?? []).length;
      expect(markerCount).toBe(1);

      // Original content preserved
      expect(content).toContain('I know TypeScript well');
    });

    it('syncs multiple agents', async () => {
      const agents = ['frontend', 'backend', 'tester'];
      for (const agent of agents) {
        mkdirSync(join(tempDir, '.squad', 'agents', agent), { recursive: true });
      }

      const config = buildDefaultConfig('test', 'owner', 'repo');
      config.squad.agents = agents;
      const bridge = new KnowledgeBridge(tempDir, config);
      const result = await bridge.syncFeatures([makeFeature()]);

      expect(result.agentsUpdated).toBe(3);
    });

    it('records decisions in decisions.md only once', async () => {
      mkdirSync(join(tempDir, '.squad'));
      mkdirSync(join(tempDir, '.squad', 'agents', 'backend'), { recursive: true });

      const config = buildDefaultConfig('test', 'owner', 'repo');
      config.squad.agents = ['backend'];
      const bridge = new KnowledgeBridge(tempDir, config);

      // Call twice — decisions should only be appended once
      await bridge.syncFeatures([makeFeature()]);
      await bridge.syncFeatures([makeFeature()]);

      const decisionsPath = join(tempDir, '.squad', 'decisions.md');
      const content = readFileSync(decisionsPath, 'utf-8');
      const count = (content.match(/Enmarchia Integration Active/g) ?? []).length;
      expect(count).toBe(1);
    });
  });
});
