/**
 * Tests for IssueCreator
 * Uses mocks to simulate GitHub API responses.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import type { EnmarchiaConfig, SpecKitFeature } from '../src/types.js';

// ---------------------------------------------------------------------------
// Shared mock setup
// ---------------------------------------------------------------------------

const mockCreate = vi.fn();
const mockGetLabel = vi.fn();
const mockCreateLabel = vi.fn();
const mockPaginate = vi.fn();
const mockListForRepo = vi.fn();

vi.mock('@octokit/rest', () => ({
  Octokit: vi.fn().mockImplementation(() => ({
    issues: {
      create: mockCreate,
      getLabel: mockGetLabel,
      createLabel: mockCreateLabel,
      listForRepo: mockListForRepo,
    },
    paginate: mockPaginate,
  })),
}));

// Import AFTER mocking
const { IssueCreator } = await import('../src/core/issue-creator.js');

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeConfig(token = 'test-token'): EnmarchiaConfig {
  return {
    project: 'Test Project',
    github: { owner: 'acme', repo: 'test-repo', token },
    specKit: { featuresDir: 'specs', constitutionFile: 'specs/CONSTITUTION.md' },
    squad: { dir: '.squad', teamName: 'Test Squad', watchInterval: 10, agents: [] },
    bridge: {
      labels: ['enmarchia', 'squad'],
      autoSync: true,
      issuePrefix: '[Enmarchia]',
    },
  };
}

function makeFeature(tasks: SpecKitFeature['tasks'] = []): SpecKitFeature {
  return {
    id: '001',
    name: 'User Auth',
    slug: 'user-auth',
    path: '/tmp/specs/spec-user-auth',
    spec: '# Spec\nUsers can log in.',
    plan: '# Plan\nUse JWT.',
    tasks,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('IssueCreator', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('constructor', () => {
    it('throws when no token is provided', () => {
      const config = makeConfig('test-token');
      delete config.github.token;
      expect(() => new IssueCreator(config)).toThrow(/token/i);
    });

    it('creates instance when token is present', () => {
      const config = makeConfig('valid-token');
      expect(() => new IssueCreator(config)).not.toThrow();
    });
  });

  describe('bridgeFeature()', () => {
    it('creates issues for pending unbridged tasks', async () => {
      mockCreate.mockResolvedValue({ data: { number: 10 } });

      const config = makeConfig();
      const creator = new IssueCreator(config);
      const feature = makeFeature([
        {
          id: '001-1',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Build login API',
          completed: false,
          level: 0,
        },
        {
          id: '001-2',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Write tests',
          completed: false,
          level: 0,
        },
      ]);

      const result = await creator.bridgeFeature(feature);

      expect(result.created).toBe(2);
      expect(result.skipped).toBe(0);
      expect(result.errors).toHaveLength(0);
      expect(mockCreate).toHaveBeenCalledTimes(2);
    });

    it('skips completed tasks', async () => {
      const config = makeConfig();
      const creator = new IssueCreator(config);
      const feature = makeFeature([
        {
          id: '001-1',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Done task',
          completed: true,
          level: 0,
        },
      ]);

      const result = await creator.bridgeFeature(feature);

      expect(result.created).toBe(0);
      expect(result.skipped).toBe(1);
      expect(mockCreate).not.toHaveBeenCalled();
    });

    it('skips tasks that already have an issue number', async () => {
      const config = makeConfig();
      const creator = new IssueCreator(config);
      const feature = makeFeature([
        {
          id: '001-1',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Already bridged',
          completed: false,
          level: 0,
          issueNumber: 99,
        },
      ]);

      const result = await creator.bridgeFeature(feature);

      expect(result.created).toBe(0);
      expect(result.skipped).toBe(1);
      expect(mockCreate).not.toHaveBeenCalled();
    });

    it('records errors for individual task failures without stopping', async () => {
      mockCreate
        .mockResolvedValueOnce({ data: { number: 1 } })
        .mockRejectedValueOnce(new Error('API rate limit'));

      const config = makeConfig();
      const creator = new IssueCreator(config);
      const feature = makeFeature([
        {
          id: '001-1',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Task 1',
          completed: false,
          level: 0,
        },
        {
          id: '001-2',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Task 2',
          completed: false,
          level: 0,
        },
      ]);

      const result = await creator.bridgeFeature(feature);

      expect(result.created).toBe(1);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]).toContain('API rate limit');
    });

    it('includes spec and plan in issue body', async () => {
      mockCreate.mockResolvedValue({ data: { number: 5 } });

      const config = makeConfig();
      const creator = new IssueCreator(config);
      const feature = makeFeature([
        {
          id: '001-1',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Build login',
          completed: false,
          level: 0,
        },
      ]);

      await creator.bridgeFeature(feature);

      const callArgs = mockCreate.mock.calls[0]?.[0] as { body: string; title: string };
      expect(callArgs.body).toContain('Users can log in');
      expect(callArgs.body).toContain('Use JWT');
      expect(callArgs.title).toContain('[Enmarchia]');
      expect(callArgs.title).toContain('[User Auth]');
      expect(callArgs.title).toContain('Build login');
    });

    it('calls onProgress callback for each created issue', async () => {
      mockCreate.mockResolvedValue({ data: { number: 7 } });

      const config = makeConfig();
      const creator = new IssueCreator(config);
      const feature = makeFeature([
        {
          id: '001-1',
          featureId: '001',
          featureName: 'User Auth',
          description: 'Task X',
          completed: false,
          level: 0,
        },
      ]);

      const progressCalls: Array<{ issueNumber: number }> = [];
      await creator.bridgeFeature(feature, (_task, issueNumber) => {
        progressCalls.push({ issueNumber });
      });

      expect(progressCalls).toHaveLength(1);
      expect(progressCalls[0]!.issueNumber).toBe(7);
    });
  });

  describe('ensureLabels()', () => {
    it('does not create labels that already exist', async () => {
      mockGetLabel.mockResolvedValue({ data: { name: 'enmarchia' } });

      const config = makeConfig();
      const creator = new IssueCreator(config);
      await creator.ensureLabels();

      expect(mockCreateLabel).not.toHaveBeenCalled();
    });

    it('creates labels that do not exist', async () => {
      mockGetLabel.mockRejectedValue(new Error('Not Found'));
      mockCreateLabel.mockResolvedValue({ data: {} });

      const config = makeConfig();
      const creator = new IssueCreator(config);
      await creator.ensureLabels();

      expect(mockCreateLabel).toHaveBeenCalledTimes(2); // enmarchia + squad
    });
  });
});
