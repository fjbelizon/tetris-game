/**
 * Tests for configuration management
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdtempSync, rmSync, writeFileSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import {
  buildDefaultConfig,
  configExists,
  loadConfig,
  saveConfig,
  CONFIG_FILENAME,
} from '../src/config.js';

describe('Config', () => {
  let tempDir: string;

  beforeEach(() => {
    tempDir = mkdtempSync(join(tmpdir(), 'enmarchia-config-test-'));
  });

  afterEach(() => {
    rmSync(tempDir, { recursive: true, force: true });
    // Clean up env vars
    delete process.env['GITHUB_TOKEN'];
    delete process.env['GH_TOKEN'];
  });

  // ---------------------------------------------------------------------------
  // configExists
  // ---------------------------------------------------------------------------
  describe('configExists()', () => {
    it('returns false when config file does not exist', () => {
      expect(configExists(tempDir)).toBe(false);
    });

    it('returns true when config file exists', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      saveConfig(tempDir, config);
      expect(configExists(tempDir)).toBe(true);
    });
  });

  // ---------------------------------------------------------------------------
  // buildDefaultConfig
  // ---------------------------------------------------------------------------
  describe('buildDefaultConfig()', () => {
    it('creates config with provided values', () => {
      const config = buildDefaultConfig('My App', 'acme', 'my-app');
      expect(config.project).toBe('My App');
      expect(config.github.owner).toBe('acme');
      expect(config.github.repo).toBe('my-app');
    });

    it('sets sensible defaults for optional fields', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      expect(config.specKit.featuresDir).toBe('specs');
      expect(config.squad.dir).toBe('.squad');
      expect(config.squad.watchInterval).toBe(10);
      expect(config.bridge.labels).toContain('enmarchia');
      expect(config.bridge.autoSync).toBe(true);
      expect(config.bridge.issuePrefix).toBe('[Enmarchia]');
    });
  });

  // ---------------------------------------------------------------------------
  // saveConfig / loadConfig
  // ---------------------------------------------------------------------------
  describe('saveConfig() / loadConfig()', () => {
    it('round-trips config correctly', () => {
      const original = buildDefaultConfig('Round Trip', 'owner', 'repo');
      saveConfig(tempDir, original);
      const loaded = loadConfig(tempDir);

      expect(loaded.project).toBe('Round Trip');
      expect(loaded.github.owner).toBe('owner');
      expect(loaded.github.repo).toBe('repo');
    });

    it('does NOT write token to disk', () => {
      const config = buildDefaultConfig('test', 'owner', 'repo');
      config.github.token = 'secret-token-12345';
      saveConfig(tempDir, config);

      const { readFileSync } = require('fs') as typeof import('fs');
      const raw = readFileSync(join(tempDir, CONFIG_FILENAME), 'utf-8');
      expect(raw).not.toContain('secret-token');
    });

    it('loads token from GITHUB_TOKEN env var', () => {
      process.env['GITHUB_TOKEN'] = 'env-token-xyz';
      const config = buildDefaultConfig('test', 'owner', 'repo');
      saveConfig(tempDir, config);

      const loaded = loadConfig(tempDir);
      expect(loaded.github.token).toBe('env-token-xyz');
    });

    it('loads token from GH_TOKEN env var as fallback', () => {
      process.env['GH_TOKEN'] = 'gh-token-abc';
      const config = buildDefaultConfig('test', 'owner', 'repo');
      saveConfig(tempDir, config);

      const loaded = loadConfig(tempDir);
      expect(loaded.github.token).toBe('gh-token-abc');
    });

    it('throws when config file does not exist', () => {
      expect(() => loadConfig(tempDir)).toThrow('not found');
    });

    it('throws when config file has invalid JSON', () => {
      writeFileSync(join(tempDir, CONFIG_FILENAME), '{invalid json}', 'utf-8');
      expect(() => loadConfig(tempDir)).toThrow(/parse/i);
    });

    it('throws when required fields are missing', () => {
      writeFileSync(
        join(tempDir, CONFIG_FILENAME),
        JSON.stringify({ project: '' }),
        'utf-8'
      );
      expect(() => loadConfig(tempDir)).toThrow(/invalid configuration/i);
    });
  });
});
