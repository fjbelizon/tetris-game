# Commands Reference

## enmarchia init

Inicializa ENMARCHIA en el proyecto actual.

Versiones requeridas por ENMARCHIA:
- specify-cli v0.5.0
- @bradygaster/squad-cli v0.9.1

Uso:

enmarchia init [options]

Opciones:
- --owner <owner>: owner de GitHub (usuario u organizacion).
- --repo <repo>: nombre del repositorio.
- --force: re-inicializa si ya existe configuracion.
- --with-spec-kit: ejecuta specify init desde ENMARCHIA.
- --with-squad: ejecuta squad init desde ENMARCHIA.
- --with-squad-copilot: ejecuta squad copilot despues de squad init.
- -y, --yes: evita prompts interactivos.

Resultados:
- Crea .enmarchia.json.
- Crea squad.agent.md.
- Crea .copilot/enmarchia.md.
- Crea specs/CONSTITUTION.md si no existe.
- Puede inicializar Spec-Kit y Squad con flags.

Ejemplo:

enmarchia init --owner acme --repo api-core --with-spec-kit --with-squad --with-squad-copilot --yes

## enmarchia bridge

Convierte tareas de Spec-Kit en issues de GitHub.

Uso:

enmarchia bridge [options]

Opciones:
- --feature <id>: procesa solo una feature (id o slug).
- --dry-run: muestra preview sin crear issues.
- --force: ignora anotaciones y reprocesa.
- --skip-sync: evita auto-sync tras bridge.

Resultados:
- Lee specs/spec-xxx/tasks.md.
- Crea un issue por tarea pendiente sin issue number.
- Anota tasks.md con (#N).
- Puede sincronizar conocimiento de agentes automaticamente.

Ejemplos:
- enmarchia bridge
- enmarchia bridge --feature spec-user-auth
- enmarchia bridge --dry-run

## enmarchia sync

Sincroniza conocimiento de spec/plan a Squad.

Uso:

enmarchia sync [options]

Opciones:
- --feature <id>: sincroniza solo una feature.
- --agents <names...>: sincroniza solo agentes indicados.

Resultados:
- Escribe .squad/enmarchia-specs.md.
- Actualiza .squad/agents/<agent>/history.md.

Ejemplos:
- enmarchia sync
- enmarchia sync --feature spec-user-auth
- enmarchia sync --agents backend tester

## enmarchia launch

Lanza ejecucion autonoma de Squad para issues de ENMARCHIA.

Uso:

enmarchia launch [options]

Opciones:
- --interval <minutes>: intervalo de polling.
- --agent-cmd <cmd>: comando del agente.
- --copilot-flags <flags>: flags para runner del agente.
- --auth-user <user>: usuario de autenticacion GitHub.
- --log-file <path>: archivo de log espejo.
- --state-backend <backend>: in-memory | git-notes | orphan-branch.
- --overnight-start <HH:MM>: pausa nocturna.
- --overnight-end <HH:MM>: reanudacion nocturna.
- --dry-run: imprime comando sin lanzar.
- --health: consulta estado del watch.

Ejemplos:
- enmarchia launch
- enmarchia launch --interval 5
- enmarchia launch --overnight-start 20:00 --overnight-end 08:00
- enmarchia launch --health

## enmarchia status

Muestra salud del pipeline completo.

Uso:

enmarchia status [options]

Opciones:
- --json: salida en JSON.

Muestra:
- Estado de Spec-Kit (features/tareas).
- Estado de Squad (agentes/watch).
- Estado del bridge (issues y tareas sin bridge).
