# Changelog

## 0.1.5 - 2026-04-08

### Added

- **`enmarchia launch --mode copilot`**: Assigns open Enmarchia issues directly to the @copilot coding agent for remote autonomous execution. Creates the `squad:copilot` label if missing, and attempts direct agent assignment via the GitHub API with label-based workflow fallback.
- **`enmarchia launch --mode local`**: Executes issues sequentially on the user's machine via `gh copilot`, enabling local autonomous development without relying on remote triage infrastructure.
- **`enmarchia launch --mode offline`**: Executes pending Spec-Kit tasks locally via `gh copilot` without generating or consuming GitHub issues.
- **`enmarchia launch --feature <id>`**: In offline mode, limits execution to a single feature ID/slug from Spec-Kit.
- **`enmarchia launch --issues <numbers...>`**: Filters execution to specific issue numbers. Works with all three modes (`squad`, `copilot`, `local`).
- **`enmarchia launch --force-reopen`**: Reopens closed issues before processing. Only works in combination with `--issues`. Closed issues are skipped by default.
- **`enmarchia launch --all`**: Processes all open Enmarchia issues at once.
- **Automatic `COPILOT_ASSIGN_TOKEN` setup in `enmarchia init`**: During initialization, ENMARCHIA now attempts to configure the repository secret required by the `Assign @copilot coding agent` GitHub Actions step.
- **`enmarchia --reconfigure-token`**: New top-level command flow to (re)configure `COPILOT_ASSIGN_TOKEN` manually after initialization.
- **`IssueCreator.listAllEnmarchiaIssues()`**: Lists all Enmarchia-managed issues (open + closed) with `state_reason` metadata for filtering.
- **`IssueCreator.reopenIssue()`**: Reopens a closed issue by setting its state back to `open`.
- **`IssueCreator.assignCopilotToIssue()`**: Assigns the Copilot coding agent to an issue via label + direct assignee, with graceful fallback.

### Fixed

- **CRITICAL**: `enmarchia launch` (default mode `squad`) only delegated to `squad triage` which requires pre-configured `@copilot` in the team roster and specific GitHub Actions workflows to actually execute work on issues. Issues were triaged and labeled but never implemented autonomously. The new `--mode copilot` and `--mode local` modes provide direct autonomous execution paths that work out of the box.
- Closed issues are now skipped by default in all modes. Use `--issues <numbers...> --force-reopen` to explicitly reopen and process specific closed issues.

### Changed

- `enmarchia launch` default behavior is unchanged (`--mode squad`). Existing users are not affected.
- Launch banner now displays the active mode for clarity.
- `enmarchia launch --all` now targets open issues only. Closed issues require explicit `--issues <numbers...> --force-reopen`.
- `enmarchia launch --mode offline` bypasses GitHub preflight and issue orchestration, and works directly from local Spec-Kit tasks.

## 0.1.4 - 2026-04-07

### Fixed

- **CRITICAL**: Fixed `enmarchia launch` not syncing Spec-Kit knowledge to Squad agents before starting watch mode. Without this sync, agents were assigned issues but lacked the specification context needed to implement them, resulting in zero progress despite successful issue assignment. Now `launch` automatically invokes `KnowledgeBridge.syncFeatures()` to populate `.squad/enmarchia-specs.md` and agent history files with full spec context before spawning the Squad process.
- Fixed `enmarchia launch` on Windows/Node.js 24 by hardening Squad process spawning to avoid `spawn EINVAL` during runtime startup.
- Fixed launch argument handling to avoid duplicate `--execute` propagation and improve shell-safe command construction.
- Fixed autonomous triage labeling failures by ensuring missing `squad:<member>` GitHub labels are auto-created from `.squad/team.md` members before watch mode starts.

### Docs

- Updated installation guidance and compatibility notes to recommend ENMARCHIA `v0.1.4` as the baseline version.

## 0.1.3 - 2026-04-07

### Fixed

- Fixed `enmarchia bridge --force` so it truly re-processes non-completed tasks already annotated with `(#N)` in `tasks.md`.
- Fixed bridge task annotation updates to replace stale issue references with the latest created issue number during forced re-bridge.
- Fixed `tasks.md` parsing on Windows CRLF files so checklist tasks are detected correctly by `status` and `bridge`.
- Fixed ESM compatibility in knowledge sync so `bridge` no longer crashes with `ReferenceError: require is not defined` on Node.js 24 during Squad agent auto-detection.
- Fixed `enmarchia launch` failure when `.squad/team.md` had no members by auto-generating a task-driven Squad roster before starting `squad triage`.

## 0.1.2 - 2026-04-07

### Fixed

- Fixed `enmarchia init` next steps messaging to reflect real execution outcomes.
- Prevented false-positive success text for Spec-Kit when `specify init` is skipped.
- Fixed automatic Spec-Kit initialization on Windows by forcing non-interactive init and UTF-8 Python output.
- Fixed `enmarchia bridge --spec-path` path resolution for absolute/relative paths and Windows separators.

### Changed

- Extended spec directory pattern support to recognize both `spec-xxx` and `nnn-xxx` format (generated by Spec-Kit's `/speckit.specify` command).
- **Breaking**: `enmarchia bridge` now requires `--spec-path` parameter to specify target spec directory directly (enables direct Squad mapping to specific specifications).

## 0.1.1 - 2026-04-07

### Fixed

- Resolved release/docs mismatch for `enmarchia init --with-squad-copilot` by publishing the option as part of version 0.1.1.

### Docs

- Added compatibility guidance for ENMARCHIA 0.1.0 vs 0.1.1+.
- Added explicit upgrade/install instruction to 0.1.1.

## 0.1.0 - 2026-04-06

- Initial public release.
