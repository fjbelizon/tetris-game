# ENMARCHIA Workflow

Este documento define el flujo operativo oficial para ejecutar ENMARCHIA como capa sobre Spec-Kit y Squad.

## Flujo en 8 pasos

1. Inicializa proyecto y herramientas:
   enmarchia init --owner <owner> --repo <repo> --with-spec-kit --with-squad --with-squad-copilot

2. Define principios del proyecto:
   /speckit.constitution

3. Define alcance funcional:
   /speckit.specify

4. Resuelve ambiguedades:
   /speckit.clarify

5. Define plan tecnico:
   /speckit.plan

6. Genera checklist de tareas:
   /speckit.tasks

7. Convierte tareas en trabajo ejecutable:
   enmarchia bridge
   enmarchia sync
   **Prerequisito:** la rama actual debe estar mergeada en `main`. Squad Configuration (.squad/team.md, .squad/agents/*) debe existir en la rama por defecto (main) para que GitHub Actions pueda procesarla correctamente.

8. Ejecuta autonomia y monitorea:
   enmarchia launch
   enmarchia status

## Contrato de estructura

ENMARCHIA procesa exclusivamente:

specs/
- CONSTITUTION.md
- spec-xxx/
  - spec.md
  - plan.md
  - tasks.md

Reglas:
- Carpetas de feature deben iniciar con spec-.
- tasks.md debe usar checkboxes markdown: - [ ] o - [x].
- Una tarea pendiente sin (#N) es candidata a bridge.

## Ciclo iterativo recomendado

Cuando cambies requisitos o plan:
1. Actualiza spec (speckit.specify / speckit.plan / speckit.tasks).
2. Ejecuta enmarchia bridge para nuevas tareas.
3. Ejecuta enmarchia sync para refrescar contexto de agentes.
4. Mantiene enmarchia launch activo o relanzalo.

## Checklist de control

Antes de bridge:
- Rama actual debe estar mergeada en `main` (rama por defecto).
- .squad/team.md con miembros definidos debe estar en main.
- .squad/agents/* debe estar en main del repositorio.

Antes de launch:
- specs existe y contiene spec-xxx.
- .squad existe.
- gh auth status OK.
- GITHUB_TOKEN disponible.
- specify-cli en v0.5.0.
- @bradygaster/squad-cli en v0.9.1.

Despues de bridge:
- tasks anotado con (#N) cuando corresponde.
- Issues con labels enmarchia/squad.

Durante ejecucion:
- Revisar PRs y mergear segun politicas del equipo.
- Ejecutar enmarchia status para validar salud del pipeline.
