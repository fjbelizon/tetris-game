# Changelog

## 0.1.1 - 2026-04-07

### Fixed

- Resolved release/docs mismatch for `enmarchia init --with-squad-copilot` by publishing the option as part of version 0.1.1.

### Docs

- Added compatibility guidance for ENMARCHIA 0.1.0 vs 0.1.1+.
- Added explicit upgrade/install instruction to 0.1.1.

## 0.1.0 - 2026-04-06

- Initial public release.
